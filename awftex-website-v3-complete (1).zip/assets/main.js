document.addEventListener('DOMContentLoaded', function () {
  var toggle = document.querySelector('.mobile-toggle');
  var nav = document.querySelector('nav.primary');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      nav.classList.toggle('open');
    });
    nav.querySelectorAll('.haschild > button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (window.innerWidth > 980) return;
        btn.parentElement.classList.toggle('active');
      });
    });
  }

  var forms = document.querySelectorAll('.enquiry-form');
  forms.forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type=submit]');
      if (btn) {
        btn.textContent = 'Enquiry received — our team will call you back shortly';
        btn.disabled = true;
        btn.style.opacity = '.85';
      }
    });
  });

  var revealables = document.querySelectorAll('.sol-card, .value-card, .process-card, .article-card, .timeline-item, .product, .industry-tile, .loc-card, .related-grid a, .schem-tile');
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.style.transitionDelay = en.target.dataset.revealDelay || '0ms';
          en.target.style.opacity = '1';
          en.target.style.transform = 'translateY(0) scale(1)';
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    var groupCounters = {};
    revealables.forEach(function (el) {
      var parent = el.parentElement;
      var key = parent ? (parent.className || 'root') : 'root';
      groupCounters[key] = (groupCounters[key] || 0) + 1;
      var idx = groupCounters[key] - 1;
      el.dataset.revealDelay = Math.min(idx * 60, 360) + 'ms';
      el.style.opacity = '0';
      el.style.transform = 'translateY(18px) scale(.98)';
      el.style.transition = 'opacity .55s ease, transform .55s cubic-bezier(.2,.7,.2,1)';
      io.observe(el);
    });
  }
});
