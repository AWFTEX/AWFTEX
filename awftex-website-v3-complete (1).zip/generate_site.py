import os, re, json, hashlib

ROOT = "/home/claude/site"
SITE_URL = "https://awftex.com"

# ---------------- brand / contact ----------------
BRAND = dict(
    legal_name="AWFTEX Industries",
    short_name="AWFTEX",
    email="office@awftex.com",
    phone_display="+91 99156 01687",
    phone_tel="+919915601687",
    whatsapp_num="919915601687",
    office_address="E-324, Jaitpur Extension Part II, New Delhi - 110044, India",
    plant_address="Plot 01, Mindkali, Budhana, Muzaffarnagar, Uttar Pradesh - 251309, India",
    tagline="Engineering Solutions. Empowering Growth.",
)

def wa_link(text):
    import urllib.parse
    return "https://wa.me/%s?text=%s" % (BRAND['whatsapp_num'], urllib.parse.quote(text))

SITEMAP_URLS = []

def slug(s):
    s = s.lower()
    s = s.replace('₂','2').replace('/', ' ').replace('&', 'and')
    s = re.sub(r'[^a-z0-9]+', '-', s).strip('-')
    return s

# ---------------- image helper (stable placeholder photography) ----------------
def photo_url(seed, w=1200, h=800):
    h_seed = hashlib.md5(seed.encode()).hexdigest()[:10]
    return "https://picsum.photos/seed/%s/%s/%s" % (h_seed, w, h)

def media(seed, tone="tone-card", w=1200, h=800, alt="", cls=""):
    return ('<div class="photo-media %s %s"><img src="%s" alt="%s" loading="lazy" width="%s" height="%s"></div>'
            % (tone, cls, photo_url(seed, w, h), alt.replace('"', "'"), w, h))

ICONS = {
  'flame':'<path d="M12 2c1 3-3 4-3 8a3 3 0 0 0 6 0c1 1 2 3 2 5a5 5 0 0 1-10 0c0-4 3-5 3-9 0-1.5.5-3 2-4z"/>',
  'panel':'<rect x="4" y="3" width="16" height="18"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  'factory':'<path d="M3 21V10l6 4v-4l6 4V6h6v15H3z"/><path d="M7 21v-4M12 21v-4M17 21v-4"/>',
  'milk':'<path d="M9 2h6l1 4-2 2v12a2 2 0 0 1-2 2h0a2 2 0 0 1-2-2V8L8 6l1-4z"/>',
  'droplet':'<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z"/>',
  'sun':'<circle cx="12" cy="12" r="4.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
  'cctv':'<rect x="3" y="7" width="12" height="7"/><path d="M15 9.5 21 7v7l-6-2.5"/><circle cx="7" cy="10.5" r="1.4"/>',
  'wind':'<path d="M3 8h10a3 3 0 1 0-3-3"/><path d="M3 13h14a3 3 0 1 1-3 3"/><path d="M3 18h8a2.5 2.5 0 1 0-2.5-2.5"/>',
  'building':'<rect x="4" y="3" width="16" height="18"/><path d="M8 7h2M8 11h2M8 15h2M14 7h2M14 11h2M14 15h2M10 21v-4h4v4"/>',
  'crate':'<path d="M3 8l9-5 9 5-9 5-9-5z"/><path d="M3 8v9l9 5 9-5V8"/><path d="M12 13v9"/>',
  'pin':'<path d="M12 22s7-7.58 7-12.5A7 7 0 0 0 5 9.5C5 14.42 12 22 12 22z"/><circle cx="12" cy="9.5" r="2.4"/>',
  'phone':'<path d="M6 3h3l1.5 5-2 2a12 12 0 0 0 5.5 5.5l2-2 5 1.5v3a2 2 0 0 1-2.2 2A18 18 0 0 1 4 6.2 2 2 0 0 1 6 3z"/>',
  'mail':'<rect x="3" y="5" width="18" height="14"/><path d="M4 6l8 6 8-6"/>',
  'whatsapp':'<path d="M8 20l-4 1 1-4a8 8 0 1 1 3 3z"/><path d="M9 9c0 3 2.5 6 6 6" stroke-linecap="round"/>',
  'check':'<path d="M20 6L9 17l-5-5"/>',
  'target':'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".6" fill="currentColor"/>',
  'shield':'<path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/>',
  'compass':'<circle cx="12" cy="12" r="9"/><path d="M15 9l-2 6-6 2 2-6 6-2z"/>',
  'layers':'<path d="M12 3l9 5-9 5-9-5 9-5z"/><path d="M3 13l9 5 9-5"/>',
  'clock':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
  'arrow':'<path d="M5 12h14M13 6l6 6-6 6"/>',
  'spark':'<path d="M12 2v6M12 16v6M2 12h6M16 12h6M5 5l4 4M15 15l4 4M19 5l-4 4M9 15l-4 4"/>',
  'wrench':'<path d="M14.7 6.3a4 4 0 0 1-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 1 5.4-5.4l-3-3z"/>',
  'building2':'<path d="M4 21V8l8-5 8 5v13"/><path d="M9 21v-6h6v6M4 21h16"/>',
  'hospital':'<rect x="4" y="10" width="16" height="11"/><path d="M9 10V4h6v6M10 15h4M12 13v4"/>',
  'store':'<path d="M4 9l1-5h14l1 5"/><path d="M4 9v11h16V9"/><path d="M9 20v-6h6v6"/>',
  'campus':'<path d="M12 3L2 8l10 5 10-5-10-5z"/><path d="M6 12v5c0 1.5 3 3 6 3s6-1.5 6-3v-5"/>',
  'ship':'<path d="M3 15l2 5h14l2-5-9-3-9 3z"/><path d="M12 12V4M9 6h6"/>',
  'cylinder':'<path d="M9 3h6v3l1.5 1.5V20a1 1 0 0 1-1 1h-7a1 1 0 0 1-1-1V7.5L9 6V3z"/><path d="M8 11h8"/>',
  'bell':'<path d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6.5H4c.5-1 2-2.5 2-6.5z"/><path d="M10 19a2 2 0 0 0 4 0"/>',
  'valve':'<circle cx="12" cy="12" r="4"/><path d="M2 12h6M16 12h6M12 2v6M12 16v6"/>',
  'hose':'<path d="M4 6c4 0 3 5 7 5s3-5 7-5"/><path d="M4 18c4 0 3-5 7-5s3 5 7 5"/><circle cx="4" cy="6" r="1.6"/><circle cx="18" cy="18" r="1.6"/>',
  'sprinkler':'<path d="M12 3v4"/><circle cx="12" cy="10" r="3"/><path d="M6 21c0-5 3-7 6-7s6 2 6 7"/>',
  'tank':'<path d="M5 8c0-2.8 3.1-5 7-5s7 2.2 7 5v9c0 2.8-3.1 5-7 5s-7-2.2-7-5V8z"/><path d="M5 8c0 2 3 3.5 7 3.5s7-1.5 7-3.5"/>',
  'gauge':'<circle cx="12" cy="13" r="8"/><path d="M12 13l4-4"/><path d="M9 4.5 12 3l3 1.5"/>',
  'fan':'<circle cx="12" cy="12" r="1.6"/><path d="M12 12c0-3.5 2-6 5-6 1 2 0 5-5 6z"/><path d="M12 12c-3.5 0-6-2-6-5 2-1 5 0 6 5z"/><path d="M12 12c0 3.5-2 6-5 6-1-2 0-5 5-6z"/><path d="M12 12c3.5 0 6 2 6 5-2 1-5 0-6-5z"/>',
  'filter':'<path d="M4 4h16l-6 8v6l-4 2v-8z"/>',
  'battery':'<rect x="3" y="8" width="16" height="9" rx="1.5"/><path d="M20 11v3"/><path d="M8 12v3M12 12v3"/>',
  'solarpanel':'<rect x="3" y="6" width="18" height="12" rx="1"/><path d="M9 6v12M15 6v12M3 12h18"/>',
  'lock':'<rect x="5" y="11" width="14" height="9" rx="1.5"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  'fingerprint':'<path d="M12 3a7 7 0 0 1 7 7c0 3-1 4-1 7"/><path d="M12 3a7 7 0 0 0-7 7c0 5 3 6 3 9"/><path d="M12 8a3.5 3.5 0 0 1 3.5 3.5c0 3.5-1.5 4.5-1.5 7"/><path d="M10 19c0-2 1-3 1-6.5A1.5 1.5 0 0 1 13 11"/>',
  'server':'<rect x="4" y="4" width="16" height="7" rx="1"/><rect x="4" y="13" width="16" height="7" rx="1"/><path d="M7.5 7.5h.01M7.5 16.5h.01"/>',
  'conveyor':'<rect x="3" y="14" width="18" height="4" rx="1.5"/><circle cx="7" cy="20" r="1.6"/><circle cx="17" cy="20" r="1.6"/><path d="M6 14V9l4-4h4l4 4v5"/>',
  'gear':'<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M21 12h-2.5M5.5 12H3M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8M18.4 18.4l-1.8-1.8M7.4 7.4 5.6 5.6"/>',
  'box':'<path d="M3 8l9-5 9 5-9 5-9-5z"/><path d="M3 8v9l9 5 9-5V8"/>',
  'pipe':'<path d="M4 8h9a4 4 0 0 1 4 4v0a4 4 0 0 0 4 4h-3"/><circle cx="4" cy="8" r="1.6"/><circle cx="18" cy="16" r="1.6"/>',
  'sign':'<rect x="3" y="6" width="18" height="10" rx="1.5"/><path d="M8 20h8M12 16v4"/><path d="M7 11h6M7 9h4"/>',
  'ppe':'<path d="M12 2 6 5v6c0 5 3 8.5 6 10 3-1.5 6-5 6-10V5l-6-3z"/>',
  'blanket':'<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 10h16M10 10v10"/>',
  'bucket':'<path d="M5 8h14l-1.5 11a2 2 0 0 1-2 1.8H8.5a2 2 0 0 1-2-1.8L5 8z"/><path d="M3 8h18M9 8V6a3 3 0 0 1 6 0v2"/>',
  'ladder':'<path d="M7 3v18M17 3v18M7 8h10M7 13h10M7 18h10"/>',
  'anpr':'<rect x="2" y="9" width="20" height="7" rx="1.5"/><path d="M2 12h20"/><circle cx="18" cy="12.5" r="1"/>',
  'door':'<rect x="5" y="3" width="12" height="18" rx="1"/><circle cx="14" cy="12" r="1"/>',
  'beam':'<path d="M3 6h18M3 18h18M6 6v12M18 6v12M10 6v12M14 6v12"/>',
  'roof':'<path d="M3 12 12 4l9 8"/><path d="M5 11v9h14v-9"/>',
  'wall':'<rect x="3" y="4" width="18" height="16"/><path d="M3 10h9M12 10v10M3 16h18"/>',
  'paint-roller':'<rect x="3" y="4" width="14" height="6" rx="1"/><path d="M8 10v4h4v7"/>',
  'crane':'<path d="M4 21V9l12-5v5H8"/><path d="M16 9v6l4 2"/><path d="M4 21h16"/>',
  'flask':'<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/>',
}
DIV_ACCENT = {
  'fire':('#E15B23','#FF9A3D'), 'mep':('#1C6FA8','#3FA9E0'), 'industrial':('#4B5A6B','#8A9BAE'),
  'dairy':('#1C6FA8','#7FD1D9'), 'water':('#0E7C86','#3FCBD1'), 'solar':('#D9891A','#F5C24C'),
  'security':('#3B3F8C','#6C6FD9'), 'air':('#2F7D5A','#6FCB9C'), 'infra':('#5B4630','#A98457'),
}
def icon(name, cls=""):
    full_cls = ("icon-svg " + cls).strip()
    return '<svg class="%s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">%s</svg>' % (full_cls, ICONS.get(name, ICONS['panel']))

# ---------------- illustration system (replaces stock photography) ----------------
# Every product / category / hero image on the site is an original, brand-drawn technical
# illustration built from the icon set above — not a stock photo. Zero licensing risk, and
# every image is genuinely specific to what it depicts (unlike mismatched stock photography).
ICON_KEYWORDS = [
  ('extinguisher',[('co2','cylinder'),('wheeled','cylinder'),('','cylinder')]),
]
def pick_icon(product_name, division_id, group_tag):
    n = product_name.lower()
    rules = [
      ('siren','bell'),('sounder','bell'),('hooter','bell'),('alarm','bell'),('detector','fingerprint'),
      ('call point','panel'),('panel','panel'),
      ('extinguisher','cylinder'),('blanket','blanket'),('bucket','bucket'),
      ('hose','hose'),('reel','hose'),('nozzle','hose'),('coupling','pipe'),('manifold','pipe'),
      ('hydrant','valve'),('landing valve','valve'),('valve','valve'),
      ('pump','gauge'),('jockey','gauge'),
      ('tank','tank'),('silo','tank'),('vessel','tank'),('cooler','tank'),
      ('sprinkler','sprinkler'),
      ('suppression','fan'),('deluge','sprinkler'),('pre-action','sprinkler'),
      ('signage','sign'),('sign','sign'),('lighting','bell'),
      ('ppe','ppe'),('evacuation','ladder'),('accessories','box'),
      ('cabinet','box'),
      ('ahu','fan'),('fcu','fan'),('vrf','fan'),('chiller','tank'),('cooling tower','fan'),
      ('ventilation','fan'),('exhaust','fan'),('duct','pipe'),('air distribution','fan'),
      ('lt panel','panel'),('ht panel','panel'),('mcc','panel'),('pcc','panel'),('distribution board','panel'),
      ('transformer','gear'),('busbar','pipe'),('cable','pipe'),('dg set','gear'),
      ('water supply','pipe'),('drainage','pipe'),('sewage','tank'),('plumbing','pipe'),('sanitary','pipe'),
      ('machinery','gear'),('fabrication','beam'),('material handling','conveyor'),('conveyor','conveyor'),
      ('storage system','box'),('automation','gear'),('plant equipment','gear'),('custom engineering','gear'),
      ('milk','box'),('paneer','box'),('curd','box'),('lassi','box'),('buttermilk','box'),('ghee','tank'),
      ('khoya','tank'),('homogenizer','gear'),('separator','gear'),('vending','box'),('cip','filter'),
      ('pasteurizer','tank'),('pipeline','pipe'),
      ('ro plant','filter'),('ro system','filter'),('dm plant','filter'),('softening','filter'),
      ('uv disinfection','flask'),('filtration','filter'),('etp','flask'),('stp','flask'),('mee','flask'),
      ('wastewater','flask'),('effluent','flask'),('dosing','flask'),('water transfer','gauge'),
      ('rooftop solar','solarpanel'),('industrial solar','solarpanel'),('commercial solar','solarpanel'),
      ('solar epc','solarpanel'),('mounting structure','beam'),('inverter','battery'),
      ('monitoring system','gauge'),('battery storage','battery'),('energy management','gauge'),
      ('power quality','gauge'),('energy efficiency','gear'),
      ('cctv','anpr'),('ip camera','anpr'),('ptz','anpr'),('nvr','server'),
      ('dvr','server'),('video management','server'),('access control','lock'),('biometric','fingerprint'),
      ('door controller','door'),('attendance','fingerprint'),('intercom','door'),('intrusion','bell'),
      ('perimeter','wall'),('anpr','anpr'),('security integration','lock'),
      ('purification','fan'),('dust collection','fan'),('fume extraction','fan'),
      ('pollution control','fan'),('clean air','fan'),
      ('structural','beam'),('roofing','roof'),('cladding','roof'),('flooring','wall'),('false ceiling','wall'),
      ('partition','wall'),('waterproofing','droplet'),('facade','building2'),('civil','beam'),('rcc','beam'),
      ('painting','paint-roller'),('scaffolding','crane'),
    ]
    for key, ic in rules:
        if key in n:
            return ic
    return {'fire':'flame','mep':'panel','industrial':'factory','dairy':'milk','water':'droplet',
            'solar':'sun','security':'cctv','air':'wind','infra':'building'}.get(division_id,'panel')

def illustration_svg(icon_name, division_id, seed, w=1200, h=800):
    a1, a2 = DIV_ACCENT.get(division_id, ('#0B3D66','#3FA9E0'))
    h_seed = int(hashlib.md5(seed.encode()).hexdigest()[:6], 16)
    rot = (h_seed % 7) - 3
    ox = 40 + (h_seed % 60)
    oy = 30 + (h_seed % 40)
    gid = "g%s" % hashlib.md5(seed.encode()).hexdigest()[:8]
    path = ICONS.get(icon_name, ICONS['panel'])
    return ("""<svg viewBox="0 0 %(w)s %(h)s" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="%(gid)sbg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%%" stop-color="%(a1)s"/><stop offset="100%%" stop-color="#050E1C"/>
    </linearGradient>
    <radialGradient id="%(gid)sglow" cx="50%%" cy="42%%" r="60%%">
      <stop offset="0%%" stop-color="%(a2)s" stop-opacity=".55"/><stop offset="100%%" stop-color="%(a2)s" stop-opacity="0"/>
    </radialGradient>
    <pattern id="%(gid)sgrid" width="46" height="46" patternUnits="userSpaceOnUse">
      <path d="M46 0H0V46" fill="none" stroke="#ffffff" stroke-opacity=".07" stroke-width="1"/>
    </pattern>
  </defs>
  <rect width="%(w)s" height="%(h)s" fill="url(#%(gid)sbg)"/>
  <rect width="%(w)s" height="%(h)s" fill="url(#%(gid)sgrid)"/>
  <circle cx="%(cx)s" cy="%(cy)s" r="%(r)s" fill="url(#%(gid)sglow)"/>
  <g transform="translate(%(ox)s,%(oy)s) rotate(%(rot)s %(cx2)s %(cy2)s) scale(%(scale)s)" opacity=".95">
    <g fill="none" stroke="#ffffff" stroke-width="0.9" stroke-linecap="round" stroke-linejoin="round">%(path)s</g>
  </g>
  <g stroke="%(a2)s" stroke-width="1.5" opacity=".8">
    <path d="M24 24h20M24 24v20"/><path d="M%(w1)s 24h-20M%(w1)s 24v20"/>
    <path d="M24 %(h1)sh20M24 %(h1)sv-20"/><path d="M%(w1)s %(h1)sh-20M%(w1)s %(h1)sv-20"/>
  </g>
</svg>""") % dict(w=w, h=h, gid=gid, a1=a1, a2=a2, path=path, rot=rot, ox=ox, oy=oy,
                   cx=w*0.5, cy=h*0.42, r=min(w,h)*0.42, cx2=(w-2*ox)/2, cy2=(h-2*oy)/2,
                   scale=round(min(w, h) / 30.0, 2), w1=w-24, h1=h-24)

def illustration(seed, division_id='fire', product_name='', tone="tone-card", w=1200, h=800, alt="", cls="", label=None):
    ic = pick_icon(product_name, division_id, '') if product_name else {
        'fire':'flame','mep':'panel','industrial':'factory','dairy':'milk','water':'droplet',
        'solar':'sun','security':'cctv','air':'wind','infra':'building'}.get(division_id,'panel')
    svg = illustration_svg(ic, division_id, seed, w, h)
    tagtxt = (label or alt or '').upper()
    tag = '<span class="illus-tag mono">%s</span>' % tagtxt[:30] if tagtxt else ''
    return '<div class="photo-media illus %s %s">%s%s</div>' % (tone, cls, tag, svg)

def icon_thumb(icon_name, division_id, seed):
    a1, a2 = DIV_ACCENT.get(division_id, ('#0B3D66','#3FA9E0'))
    path = ICONS.get(icon_name, ICONS['panel'])
    gid = "t%s" % hashlib.md5(seed.encode()).hexdigest()[:8]
    return ("""<svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
  <defs><linearGradient id="%(gid)s" x1="0" y1="0" x2="1" y2="1"><stop offset="0%%" stop-color="%(a1)s"/><stop offset="100%%" stop-color="%(a2)s"/></linearGradient></defs>
  <rect width="48" height="48" rx="10" fill="url(#%(gid)s)"/>
  <g transform="translate(12,12) scale(1)" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">%(path)s</g>
</svg>""") % dict(gid=gid, a1=a1, a2=a2, path=path)

DIVISIONS = [
  dict(id='fire', name='Fire & Life Safety', icon='flame',
    tagline='Detection, suppression and evacuation systems engineered to code.',
    desc='Complete fire protection — from portable extinguishers to engineered gas suppression — specified, supplied and commissioned as one scope.',
    seo='Fire fighting equipment supplier and fire safety system integrator covering detection, suppression, hydrant, sprinkler and evacuation systems for industrial and commercial facilities.',
    industries=['Manufacturing plants','Warehouses & logistics parks','Commercial high-rises','Data centres','Hospitals','Hospitality'],
    groups=[
      dict(name='Fire Extinguishers', tag='FE', items=['ABC Powder Extinguisher','CO₂ Extinguisher','Water Extinguisher','Foam Extinguisher','Clean Agent Extinguisher','Water Mist Extinguisher','Wet Chemical Extinguisher','Special Application Extinguisher','Automatic Extinguisher','Wheeled Extinguisher']),
      dict(name='Fire Alarm Systems', tag='FA', items=['Conventional Fire Alarm System','Addressable Fire Alarm System','Smoke Detector','Heat Detector','Manual Call Point','Sounder / Hooter','Fire Alarm Control Panel','Emergency & Exit System']),
      dict(name='Fire Hydrant Systems', tag='FH', items=['Hydrant Valve','Hose Reel','Hose Pipe','Landing Valve','Fire Hydrant Cabinet','Fire Pump','Jockey Pump','Fire Water Tank']),
      dict(name='Fire Sprinkler Systems', tag='FS', items=['Sprinkler Head','Wet Pipe Sprinkler System','Dry Pipe Sprinkler System','Deluge System','Pre-Action System']),
      dict(name='Fire Suppression', tag='FX', items=['Gas Suppression System','Clean Agent Suppression','Inert Gas Suppression','CO₂ Suppression System','Water Mist Suppression','Kitchen Suppression System','Electrical Panel Suppression','Server / Data Centre Suppression']),
      dict(name='Fire Fighting Equipment', tag='FG', items=['Fire Blanket','Fire Bucket','Fire Hose','Fire Nozzle','Fire Manifold','Fire Coupling','Fire Cabinet','Fire Fighting Accessories']),
      dict(name='Fire Safety & Emergency', tag='FZ', items=['Fire Safety Signage','Emergency Lighting','Exit Sign','Fire Safety PPE','Evacuation Equipment','Safety Accessories']),
    ]),
  dict(id='mep', name='MEP Engineering', icon='panel',
    tagline='HVAC, electrical, plumbing and fire systems under one scope.',
    desc='Mechanical, electrical and plumbing systems for commercial and industrial buildings, coordinated as a single engineered package.',
    seo='MEP contractor for HVAC, electrical panels, plumbing and fire-integration systems across commercial buildings, industrial facilities and campuses.',
    industries=['Commercial buildings','Industrial facilities','Hospitals','IT parks & campuses','Retail & malls','Hospitality'],
    groups=[
      dict(name='HVAC', tag='HV', items=['Air Handling Unit (AHU)','Fan Coil Unit (FCU)','VRF / VRV System','Chiller','Cooling Tower','Ventilation System','Exhaust System','Ducting','Air Distribution System']),
      dict(name='Electrical', tag='EL', items=['LT Panel','HT Panel','MCC Panel','PCC Panel','Distribution Board','Transformer','Power & Control Cables','Busbar Trunking','Industrial Lighting','Industrial Electrical System','DG Set Integration']),
      dict(name='Plumbing', tag='PL', items=['Water Supply System','Drainage System','Sewage System','Pumping System','Hot Water System','Industrial Plumbing','Sanitary System']),
      dict(name='Fire & Life Safety (MEP Scope)', tag='FL', items=['Fire Alarm Integration','Fire Hydrant Integration','Sprinkler Integration','Fire Pump Integration','Suppression Integration','Emergency System Integration']),
    ]),
  dict(id='industrial', name='Industrial Engineering', icon='factory',
    tagline='Machinery, fabrication and automation for plant operations.',
    desc='Custom machinery, process equipment and automation for manufacturing and processing plants, engineered to your line requirements.',
    seo='Industrial engineering company for custom machinery, fabrication, material handling and plant automation across manufacturing and process industries.',
    industries=['Manufacturing','Process industries','Warehousing & logistics','Heavy engineering','Food & beverage plants','Chemical plants'],
    groups=[
      dict(name='Core Capabilities', tag='IE', items=['Industrial Machinery','Process Equipment','Fabrication Work','Material Handling System','Conveyor System','Storage System','Tanks & Vessels','Industrial Automation System','Plant Equipment','Custom Engineering Solution']),
    ]),
  dict(id='dairy', name='Dairy & Food Processing', icon='milk',
    tagline='From bulk milk coolers to complete turnkey dairy plants.',
    desc='Processing, chilling and packaging equipment for dairy and food production — sized from a single unit to a complete plant.',
    seo='Dairy processing equipment manufacturer and turnkey dairy plant supplier — milk chilling, pasteurization, paneer, ghee and complete dairy lines.',
    industries=['Dairy processing units','Milk cooperatives','Food manufacturing','Cold chain & logistics','Retail dairy','Hospitality & catering'],
    groups=[
      dict(name='Dairy Processing Equipment', tag='DP', items=['Bulk Milk Cooler','Milk Chilling System','Milk Pasteurizer','Milk Storage Tank','Milk Silo','Milk Homogenizer','Cream Separator','Paneer Plant','Curd Processing Plant','Lassi Processing Unit','Buttermilk Processing Unit','Ghee Plant','Khoya Machine','Milk Vending Machine','CIP System','Dairy Pipeline','Dairy Pump','Complete Dairy Plant','Custom Dairy Processing Solution']),
    ]),
  dict(id='water', name='Water & Wastewater', icon='droplet',
    tagline='Treatment, filtration and recycling for industrial water.',
    desc='Water and wastewater treatment systems, from RO and DM plants to full ETP / STP installations and effluent recycling.',
    seo='Water treatment plant supplier — RO plants, DM plants, ETP, STP, effluent recycling and industrial filtration systems.',
    industries=['Manufacturing plants','Municipal utilities','Commercial buildings','Hospitality','Pharmaceutical & chemical plants','Food & beverage plants'],
    groups=[
      dict(name='Treatment & Filtration', tag='WW', items=['RO Plant','Industrial RO System','Commercial RO System','DM Plant','Water Softening System','UV Disinfection System','Filtration Plant','Effluent Treatment Plant (ETP)','Sewage Treatment Plant (STP)','Multiple Effect Evaporator (MEE)','Wastewater Treatment System','Effluent Recycling System','Water Storage System','Dosing System','Water Transfer Pump','Filtration Equipment']),
    ]),
  dict(id='solar', name='Solar & Energy', icon='sun',
    tagline='Rooftop to industrial-scale solar, EPC to monitoring.',
    desc='Solar generation and energy management systems for commercial and industrial sites, delivered as full EPC or component supply.',
    seo='Solar EPC company for rooftop, industrial and commercial solar systems, battery storage and energy management solutions.',
    industries=['Industrial rooftops','Commercial buildings','Warehousing & logistics','Institutional campuses','Agricultural sites','Residential townships'],
    groups=[
      dict(name='Solar & Energy Systems', tag='SE', items=['Rooftop Solar System','Industrial Solar System','Commercial Solar System','Solar EPC Project','Solar Mounting Structure','Solar Inverter','Solar Monitoring System','Battery Storage System','Energy Management System','Power Quality System','Energy Efficiency Solution']),
    ]),
  dict(id='security', name='Security & Surveillance', icon='cctv',
    tagline='Cameras, access control and perimeter protection.',
    desc='Surveillance, access control and perimeter security systems integrated into a single monitored platform.',
    seo='CCTV and security system integrator — IP cameras, access control, biometric attendance and perimeter security installation.',
    industries=['Commercial buildings','Industrial facilities','Residential complexes','Retail','Educational institutions','Warehousing & logistics'],
    groups=[
      dict(name='Security Systems', tag='SC', items=['CCTV System','IP Camera','PTZ Camera','Network Video Recorder (NVR)','Digital Video Recorder (DVR)','Video Management System','Access Control System','Biometric System','Door Controller','Attendance System','Video Intercom','Intrusion Detection System','Perimeter Security System','ANPR System','Security Integration Solution']),
    ]),
  dict(id='air', name='Air & Environmental', icon='wind',
    tagline='Filtration, dust control and industrial air quality.',
    desc='Air purification, dust collection and pollution control systems for industrial environments and clean-air facilities.',
    seo='Industrial air pollution control systems — dust collection, fume extraction, ventilation and air filtration equipment supplier.',
    industries=['Manufacturing plants','Pharmaceutical facilities','Food processing units','Chemical plants','Warehousing','Workshops & fabrication units'],
    groups=[
      dict(name='Air & Environmental Systems', tag='AE', items=['Air Purification System','Industrial Air Filtration System','Dust Collection System','Fume Extraction System','Industrial Exhaust System','Ventilation System','Clean Air System','Industrial Pollution Control System']),
    ]),
  dict(id='infra', name='Infrastructure & Building', icon='building',
    tagline='Structural, envelope and finishing works alongside your MEP and fire scope.',
    desc='Structural, civil and building-envelope works coordinated with AWFTEX MEP and fire safety scopes on the same project.',
    seo='Infrastructure and building engineering contractor for structural steel, building envelope, civil and interior finishing works on industrial and commercial projects.',
    industries=['Industrial facilities','Commercial buildings','Warehouses & logistics parks','Institutional campuses','Retail & malls','Manufacturing plants'],
    groups=[
      dict(name='Structural & Civil Works', tag='SC', items=['Structural Steel Fabrication','RCC Civil Works','Foundation & Footing Work','Pre-Engineered Building (PEB) Structure','Mezzanine Floor Structure','Structural Retrofitting']),
      dict(name='Building Envelope', tag='BE', items=['Roofing System','Wall Cladding System','Building Facade Work','Waterproofing System','Skylight & Ventilator Installation','Expansion Joint Treatment']),
      dict(name='Interior & Finishing', tag='IF', items=['False Ceiling & Partition','Industrial Flooring','Epoxy Flooring System','Interior Fit-Out Work','Painting & Protective Coating'],),
      dict(name='Site & Enabling Works', tag='SW', items=['Site Grading & Earthwork','Internal Road & Paving','Boundary Wall & Fencing','Scaffolding & Access Work']),
    ]),
]

FEATURE_BANK = {
  'fire': ["Built to support rapid response during a fire emergency","Suited to continuous readiness in industrial and commercial environments","Engineered for straightforward inspection and maintenance access","Designed to integrate with the wider fire protection scope on a project","Configurable to match the layout and risk profile of your facility"],
  'mep': ["Engineered for reliable day-to-day building operation","Sized and coordinated as part of the wider MEP scope","Built for straightforward access during servicing","Suited to both new-build and retrofit projects","Configurable to match your building's load and layout"],
  'industrial': ["Engineered around your specific process and line requirements","Built for continuous industrial duty","Designed with operator safety and access in mind","Suited to integration with existing plant equipment","Configurable in capacity and layout to match your facility"],
  'dairy': ["Built for hygienic, continuous dairy processing","Engineered for straightforward cleaning and sanitation","Suited to both standalone use and full plant integration","Designed around consistent, repeatable output","Configurable in capacity to match your throughput"],
  'water': ["Engineered for consistent treated-water quality","Built for continuous industrial or commercial operation","Suited to integration with your existing water infrastructure","Designed for straightforward operation and maintenance","Configurable in capacity to match your site's demand"],
  'solar': ["Engineered for long-term outdoor performance","Sized to match your site's roof, land or load profile","Designed for straightforward monitoring and maintenance access","Suited to both new installations and capacity expansion","Configurable as full EPC or component-level supply"],
  'security': ["Built for continuous, reliable monitoring","Engineered for straightforward installation and integration","Suited to both standalone use and full system integration","Designed with operator usability in mind","Configurable to match the scale of your site"],
  'air': ["Engineered for consistent air quality performance","Built for continuous industrial operation","Suited to integration with your existing ventilation setup","Designed for straightforward filter access and maintenance","Configurable in capacity to match your facility"],
  'infra': ["Engineered to coordinate with the MEP and fire safety scope on the same project","Specified against local municipal building by-laws","Suited to both new-build and occupied-site retrofit work","Sequenced to minimise disruption on live sites","Built to structural and material standards appropriate to the work"],
}

SPEC_FIELDS = ["Capacity / Rating","Power Supply","Material of Construction","Mounting / Installation Type","Duty / Operation Cycle","Certification Status"]
SPEC_VALUE = "To be confirmed with the AWFTEX engineering team"

INDUSTRY_ICON = {
  'Manufacturing plants':'factory','Warehouses & logistics parks':'crate','Commercial high-rises':'building2',
  'Data centres':'panel','Hospitals':'hospital','Hospitality':'store','Commercial buildings':'building2',
  'Industrial facilities':'factory','IT parks & campuses':'campus','Retail & malls':'store',
  'Manufacturing':'factory','Process industries':'factory','Warehousing & logistics':'crate',
  'Heavy engineering':'wrench','Food & beverage plants':'milk','Chemical plants':'droplet',
  'Dairy processing units':'milk','Milk cooperatives':'milk','Food manufacturing':'milk',
  'Cold chain & logistics':'crate','Retail dairy':'store','Hospitality & catering':'store',
  'Municipal utilities':'droplet','Pharmaceutical & chemical plants':'droplet',
  'Industrial rooftops':'sun','Institutional campuses':'campus','Agricultural sites':'sun',
  'Residential townships':'building2','Residential complexes':'building2','Retail':'store',
  'Educational institutions':'campus','Warehousing':'crate','Workshops & fabrication units':'wrench',
  'Pharmaceutical facilities':'droplet',
}
STANDARDS_REF = {
  'fire': "Fire and life-safety equipment of this kind is typically specified with reference to National Building Code (NBC) of India Part 4, relevant Bureau of Indian Standards (BIS) specifications such as IS 2190 (hydrant systems) and IS 15683 (portable extinguishers), and NFPA guidelines where a project specification calls for them.",
  'mep': "MEP systems of this kind are typically specified with reference to National Building Code (NBC) of India Part 8 (building services), relevant BIS standards for electrical installations, and ASHRAE guidance where HVAC load calculations are involved.",
  'industrial': "Industrial machinery and fabrication work of this kind is typically specified with reference to relevant Indian Boiler Regulations, BIS standards for pressure vessels and structural steel, and factory safety norms applicable to the process involved.",
  'dairy': "Dairy processing equipment of this kind is typically specified with reference to FSSAI food-contact material norms, BIS dairy-equipment standards, and hygienic design practice for food-grade stainless steel construction.",
  'water': "Water and wastewater treatment systems of this kind are typically specified with reference to Central Pollution Control Board (CPCB) discharge norms, BIS standards for treated water quality, and state pollution control board consent conditions applicable to the site.",
  'solar': "Solar and energy systems of this kind are typically specified with reference to Ministry of New and Renewable Energy (MNRE) guidelines, BIS standards for PV modules and inverters, and the applicable state DISCOM net-metering or grid-connection policy.",
  'security': "Security and surveillance systems of this kind are typically specified with reference to relevant BIS and IP-rating standards for outdoor equipment, and any site-specific compliance requirements from local law-enforcement or facility-security guidelines.",
  'air': "Air quality and environmental control systems of this kind are typically specified with reference to CPCB emission and ambient air-quality norms, BIS ventilation standards, and factory workplace air-quality guidelines.",
  'infra': "Structural and building-envelope work of this kind is typically specified with reference to the National Building Code (NBC) of India, relevant BIS structural and material standards, and local municipal building by-laws.",
}
def standards_note(division_id):
    txt = STANDARDS_REF.get(division_id, "")
    return '<div class="standards-note">%s<p><b>A note on standards.</b> %s AWFTEX confirms the exact applicable standard for your project during engineering review — this note is general orientation, not a compliance certificate.</p></div>' % (icon('shield'), txt)

CHOOSE_CRITERIA = {
  'fire': [("Risk & occupancy class","What's being protected — people, equipment or high-value stock — sets the class of system and response time required."),
           ("Site layout & travel distance","Hydrant spacing, detector coverage and evacuation routes are laid out against your actual floor plan, not a generic assumption."),
           ("Water / agent availability","Suppression agent choice (water, foam, clean agent, gas) depends on what's in the room — server rooms and kitchens need different agents than open floor space."),
           ("Compliance sign-off","Fire NOC and insurance requirements often dictate minimum system class — this is confirmed early so the specification doesn't need rework later.")],
  'mep': [("Load profile","Connected and diversified load determines panel, cable and HVAC tonnage sizing — oversizing wastes capital, undersizing causes nuisance trips."),
          ("Occupancy pattern","A 24x7 process floor and a 9-to-6 office load HVAC and electrical systems very differently even at the same square footage."),
          ("Integration points","Where MEP needs to interface with fire alarm, BMS or DG backup is mapped before equipment is finalised."),
          ("Retrofit vs new-build","Retrofit work is constrained by existing risers, shafts and access — this changes equipment selection versus a new build.")],
  'industrial': [("Process parameters","Throughput, material and duty cycle drive machinery sizing more than a generic capacity figure."),
                 ("Layout & floor loading","Equipment footprint and floor loading are checked against your actual plant layout before fabrication drawings are finalised."),
                 ("Automation level","Manual, semi-automatic and fully automated configurations trade off capital cost against labour and consistency."),
                 ("Maintenance access","Access for routine servicing is designed in from the start, not retrofitted after installation.")],
  'dairy': [("Collection volume","Daily intake volume determines whether a bulk milk cooler or a full chilling system is the right starting point."),
            ("Product mix","A plant producing only pasteurized milk has a different equipment list than one also making paneer, ghee or curd."),
            ("Hygiene & CIP needs","Clean-in-place requirements shape pipeline, tank and valve selection from the outset."),
            ("Growth headroom","Sizing includes reasonable headroom for planned volume growth rather than only current-day throughput.")],
  'water': [("Feed water quality","Source water TDS, hardness and contaminants determine whether RO, softening, UV or a combination is needed."),
            ("Discharge / reuse target","Effluent systems are sized against the discharge or reuse standard your site must meet, not a generic percentage removal."),
            ("Peak vs average demand","Storage and pump sizing account for peak demand periods, not just daily average consumption."),
            ("Space & civil constraints","Available space for tanks, filtration skids and civil work shapes the final system layout.")],
  'solar': [("Roof / land structural capacity","Mounting structure and panel count are checked against actual structural load capacity before system size is finalised."),
            ("Shading & orientation","Shading analysis and orientation materially change realistic generation versus nameplate capacity."),
            ("Load & billing pattern","Net-metering, gross-metering or hybrid configuration depends on your load pattern and DISCOM policy."),
            ("O&M expectations","Monitoring and cleaning access are planned in so generation doesn't quietly degrade after commissioning.")],
  'security': [("Coverage priorities","Entry points, perimeters and high-value areas are prioritised before camera count is decided."),
               ("Storage & retention","Required footage retention period drives NVR/DVR storage sizing more than camera resolution alone."),
               ("Access control depth","Card, biometric or hybrid access control depends on the security tier required for different zones."),
               ("Network & power infra","Existing network and power infrastructure at site affects camera type (IP vs analog) and cabling scope.")],
  'air': [("Contaminant type","Dust, fume and general ventilation each need a different filtration and extraction approach."),
          ("Air change rate required","Required air changes per hour for the space set the fan and ducting capacity, not room size alone."),
          ("Regulatory exposure","Facilities with CPCB / pollution-control reporting obligations size systems against those specific limits."),
          ("Energy operating cost","Filtration and extraction run continuously in many facilities — energy efficiency is weighed alongside capital cost.")],
  'infra': [("Structural scope","Whether the requirement is new structural work, a building envelope upgrade, or interior finishing changes the whole approach."),
            ("Coordination with MEP/fire","Structural and envelope work is sequenced against MEP and fire safety scopes on the same project."),
            ("Municipal approvals","Local building by-law and approval requirements are confirmed before structural work begins."),
            ("Site access & phasing","Occupied-building work is phased differently from new-build to minimise disruption.")],
}
def choose_guide_html(d):
    items = CHOOSE_CRITERIA.get(d['id'], [])
    if not items:
        return ""
    cards = "".join('<div class="choose-card"><h4><span class="n mono">%02d</span>%s</h4><p>%s</p></div>' % (i+1, t, p) for i, (t, p) in enumerate(items))
    return ('<section class="pd-section" style="border-top:1px solid var(--line);"><div class="wrap">'
            '<h2>How to choose within %s</h2>'
            '<p class="body-copy" style="margin-bottom:18px;">Four factors AWFTEX\'s engineering team weighs before recommending a configuration.</p>'
            '<div class="choose-grid">%s</div>%s</div></section>') % (d['name'], cards, standards_note(d['id']))

def overview_paragraphs(product, division, group, division_id='fire'):
    p1 = ("The %s is part of AWFTEX's %s range, supplied as part of the %s solution division. "
          "It is positioned for facilities that need this class of equipment specified, sourced and installed "
          "as part of a coordinated engineering scope rather than a one-off purchase.") % (product, group, division)
    p2 = ("AWFTEX works with project teams and facility owners to confirm the right configuration of the %s for "
          "the site — covering layout, integration with adjoining systems, and installation sequencing — before "
          "finalising technical specifications and commercial terms.") % (product,)
    p3 = STANDARDS_REF.get(division_id, "")
    return [p1, p2, p3]

def faqs_for(product, division, group, division_id):
    return [
        ("What is the %s used for?" % product,
         "The %s is supplied by AWFTEX as part of the %s solution range, within the %s product group. Share your site details and our engineering team will confirm whether it's the right fit for your requirement." % (product, division, group)),
        ("Does AWFTEX handle installation and commissioning for the %s?" % product,
         "AWFTEX scopes installation and commissioning alongside supply wherever the project calls for it. Mention your requirement in the enquiry form and a project engineer will confirm the scope with you."),
        ("Can the %s be customised for my facility?" % product,
         "Configuration is confirmed against your site conditions, layout and load requirements. Share your specifications through the enquiry form for a tailored recommendation."),
        ("How do I get pricing for the %s?" % product,
         "Pricing depends on configuration, quantity and site conditions. Submit an enquiry and the AWFTEX team will respond with a formal quotation."),
        ("What lead time should I expect for the %s?" % product,
         "Lead time depends on whether the configuration is stocked, sourced, or fabricated to order, and on current site-readiness. Confirmed timelines are shared once configuration and quantity are finalised."),
        ("Does AWFTEX offer AMC or after-sales support for the %s?" % product,
         "Annual maintenance contracts and after-sales support can be scoped alongside supply and installation — mention this in your enquiry if ongoing support is part of what you need."),
    ]

def related_for(group, current):
    others = [i for i in group['items'] if i != current]
    return others[:3] if len(others) >= 3 else others

os.makedirs(ROOT, exist_ok=True)
os.makedirs(os.path.join(ROOT, 'solutions'), exist_ok=True)
os.makedirs(os.path.join(ROOT, 'company'), exist_ok=True)

def register_url(relpath):
    SITEMAP_URLS.append(relpath)

def header(prefix):
    dropdown = ""
    for d in DIVISIONS:
        dropdown += '<a href="%ssolutions/%s/index.html">%s</a>' % (prefix, d['id'], d['name'])
    return """
<header class="site">
  <div class="wrap header-inner">
    <a class="logo-mark" href="%(prefix)sindex.html">
      <img src="%(prefix)sassets/logo.png" alt="AWFTEX — Engineering Solutions. Empowering Growth." width="170" height="43">
    </a>
    <nav class="primary">
      <a href="%(prefix)scompany/about.html">Company</a>
      <div class="haschild">
        <button type="button">Solutions <span class="caret"></span></button>
        <div class="megamenu">
          %(dropdown)s
          <a class="viewall" href="%(prefix)ssolutions/index.html">View all solutions →</a>
        </div>
      </div>
      <a href="%(prefix)scompany/industries.html">Industries</a>
      <a href="%(prefix)scompany/projects.html">Projects</a>
      <a href="%(prefix)scompany/why-awftex.html">Why AWFTEX</a>
      <a href="%(prefix)scompany/insights.html">Insights</a>
    </nav>
    <div style="display:flex;align-items:center;gap:10px;">
      <a href="%(prefix)scompany/contact.html" class="cta">Get a Quote</a>
      <button class="mobile-toggle" aria-label="Menu"><span></span></button>
    </div>
  </div>
</header>
""" % dict(prefix=prefix, dropdown=dropdown)

def footer(prefix):
    sol_links = "".join('<li><a href="%ssolutions/%s/index.html">%s</a></li>' % (prefix, d['id'], d['name']) for d in DIVISIONS)
    return """
<section class="band" id="contact-band">
  <div class="band-aurora" aria-hidden="true"><span class="band-orb"></span><span class="band-orb b2"></span></div>
  <div class="wrap band-inner">
    <div>
      <div class="eyebrow on-dark"><span class="rule"></span>LET'S SPEC IT OUT</div>
      <h2>Have a system to spec out?</h2>
      <p>Send us the site, the scope, or just the problem — an AWFTEX engineer will get back to you with the right product line and a formal quotation.</p>
    </div>
    <div class="band-ctas">
      <a href="%(prefix)scompany/contact.html" class="cta">Send an Enquiry</a>
      <a href="%(wa)s" class="cta wa" target="_blank" rel="noopener">%(waicon)s WhatsApp Us</a>
    </div>
  </div>
</section>
<footer class="site">
  <div class="footer-topline" aria-hidden="true"></div>
  <div class="wrap">
    <div class="footer-grid">
      <div>
        <div class="logo-mark" style="margin-bottom:18px;"><img src="%(prefix)sassets/logo.png" alt="AWFTEX" width="150" height="38"></div>
        <p style="max-width:34ch;line-height:1.75;color:#93A3B8;">%(legal)s is a multi-solution engineering platform covering fire &amp; life safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems — one technical partner instead of nine vendors.</p>
        <div class="footer-contact">
          <a class="fc-chip" href="https://www.google.com/maps/search/?api=1&query=%(office_q)s" target="_blank" rel="noopener"><span class="fc-ic">%(pin)s</span><span>%(office)s</span></a>
          <a class="fc-chip" href="mailto:%(email)s"><span class="fc-ic">%(mailicon)s</span><span>%(email)s</span></a>
          <a class="fc-chip" href="tel:%(tel)s"><span class="fc-ic">%(phoneicon)s</span><span>%(phone)s</span></a>
        </div>
      </div>
      <div><h5>COMPANY</h5><ul>
        <li><a href="%(prefix)scompany/about.html">About AWFTEX</a></li>
        <li><a href="%(prefix)scompany/why-awftex.html">Why AWFTEX</a></li>
        <li><a href="%(prefix)scompany/projects.html">Projects</a></li>
        <li><a href="%(prefix)scompany/industries.html">Industries</a></li>
        <li><a href="%(prefix)scompany/insights.html">Insights</a></li>
      </ul></div>
      <div><h5>SOLUTIONS</h5><ul>%(sol_links)s</ul></div>
      <div><h5>REACH US</h5><ul>
        <li><a href="%(prefix)scompany/contact.html">Enquiry Form</a></li>
        <li><a href="%(wa)s" target="_blank" rel="noopener">WhatsApp</a></li>
        <li><a href="tel:%(tel)s">Call Us</a></li>
        <li><a href="mailto:%(email)s">Email Us</a></li>
      </ul></div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 %(legal)s. All rights reserved.</span>
      <span>Product photography shown is representative stock imagery pending real product photos.</span>
    </div>
  </div>
</footer>
<script src="%(prefix)sassets/main.js"></script>
""" % dict(prefix=prefix, sol_links=sol_links, legal=BRAND['legal_name'], office=BRAND['office_address'],
           email=BRAND['email'], tel=BRAND['phone_tel'], phone=BRAND['phone_display'],
           wa=wa_link("Hi AWFTEX, I'd like to enquire about your engineering solutions."),
           office_q=__import__('urllib.parse', fromlist=['quote']).quote(BRAND['office_address']),
           pin=icon('pin'), mailicon=icon('mail'), phoneicon=icon('phone'), waicon=icon('whatsapp'))

def page(prefix, title, description, body, extra_head="", canonical_path="", og_image=None):
    canonical = SITE_URL + "/" + canonical_path if canonical_path else SITE_URL + "/"
    ogimg = og_image or (SITE_URL + "/assets/logo.png")
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>%(title)s</title>
<meta name="description" content="%(description)s">
<link rel="canonical" href="%(canonical)s">
<link rel="icon" href="%(prefix)sassets/favicon.png" type="image/png">
<link rel="icon" href="%(prefix)sassets/favicon-192.png" sizes="192x192" type="image/png">
<link rel="apple-touch-icon" href="%(prefix)sassets/favicon-192.png">
<meta property="og:type" content="website">
<meta property="og:site_name" content="AWFTEX">
<meta property="og:title" content="%(title)s">
<meta property="og:description" content="%(description)s">
<meta property="og:url" content="%(canonical)s">
<meta property="og:image" content="%(ogimg)s">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#0B3D66">
<link rel="stylesheet" href="%(prefix)sassets/styles.css">
%(extra_head)s
</head>
<body>
%(body)s
</body>
</html>""" % dict(title=title, description=description, prefix=prefix, body=body, extra_head=extra_head,
                   canonical=canonical, ogimg=ogimg)

def breadcrumb(items):
    parts = []
    for i, (label, href) in enumerate(items):
        if href:
            parts.append('<a href="%s">%s</a>' % (href, label))
        else:
            parts.append('<span class="current">%s</span>' % label)
        if i < len(items) - 1:
            parts.append('<span class="sep">/</span>')
    return '<div class="wrap"><div class="breadcrumb">%s</div></div>' % "".join(parts)

def breadcrumb_jsonld(items, base_url):
    els = []
    for i, (label, href) in enumerate(items):
        url = base_url + href.lstrip('.').lstrip('/') if href else None
        item = {"@type": "ListItem", "position": i + 1, "name": label}
        if href:
            item["item"] = url
        els.append(item)
    return json.dumps({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": els})
# ---------------- PRODUCT PAGES ----------------
product_count = 0
for d in DIVISIONS:
    if d.get('pending'):
        continue
    os.makedirs(os.path.join(ROOT, 'solutions', d['id']), exist_ok=True)
    prefix = "../../"
    for g in d['groups']:
        for product in g['items']:
            product_count += 1
            pslug = slug(product)
            relpath = "solutions/%s/%s.html" % (d['id'], pslug)
            register_url(relpath)
            crumbs = breadcrumb([("Home", prefix + "index.html"), ("Solutions", prefix + "solutions/index.html"),
                                  (d['name'], prefix + "solutions/%s/index.html" % d['id']), (product, None)])
            paras = overview_paragraphs(product, d['name'], g['name'], d['id'])
            features = [f.replace("{product}", product) for f in FEATURE_BANK.get(d['id'], FEATURE_BANK['industrial'])]
            faqs = faqs_for(product, d['name'], g['name'], d['id'])
            related = related_for(g, product)
            spec_rows = "".join('<tr><td>%s</td><td>%s</td></tr>' % (f, SPEC_VALUE) for f in SPEC_FIELDS)
            related_html = "".join('<a href="%s.html">%s <span>%s</span></a>' % (slug(r), r, icon('arrow')) for r in related) or '<a href="index.html">Browse full %s range <span>%s</span></a>' % (d['name'], icon('arrow'))
            faq_html = "".join('<details class="faq-item"><summary>%s</summary><div class="a">%s</div></details>' % (q, a) for q, a in faqs)
            industries_html = "".join('<span class="chip">%s</span>' % i for i in d['industries'])
            product_seed = "awftex-%s-%s" % (d['id'], pslug)
            product_photo = SITE_URL + "/assets/logo.png"
            jsonld = json.dumps({
                "@context": "https://schema.org",
                "@type": "Product",
                "name": product,
                "category": d['name'] + " / " + g['name'],
                "description": paras[0],
                "brand": {"@type": "Brand", "name": "AWFTEX"},
                "manufacturer": {"@type": "Organization", "name": BRAND['legal_name']},
                "offers": {"@type": "Offer", "priceCurrency": "INR", "availability": "https://schema.org/InStock",
                           "url": SITE_URL + "/" + relpath, "seller": {"@type": "Organization", "name": BRAND['legal_name']}}
            })
            bc_jsonld = breadcrumb_jsonld([("Home", "index.html"), ("Solutions", "solutions/index.html"),
                                           (d['name'], "solutions/%s/index.html" % d['id']), (product, None)], SITE_URL + "/")
            wa_text = "Hi AWFTEX, I'd like to enquire about the %s." % product
            body = header(prefix) + crumbs + """
<section class="wrap" style="padding-bottom:10px;">
  <div class="product-hero framed">
    %(pmedia)s
    <div class="product-info">
      <span class="divtag mono">%(dname)s / %(gname)s</span>
      <h1>%(product)s</h1>
      <p class="lead">%(p1)s</p>
      <div class="product-ctas">
        <a href="../../company/contact.html" class="cta">Enquire Now</a>
        <a href="%(wa)s" class="cta wa" target="_blank" rel="noopener">%(waicon)s WhatsApp Us</a>
      </div>
      <div class="chip-row">%(industries)s</div>
    </div>
  </div>
</section>

<section class="pd-section"><div class="wrap">
  <h2>Overview</h2>
  <p class="body-copy">%(p1)s</p>
  <p class="body-copy">%(p2)s</p>
  <p class="body-copy">%(p3)s</p>
</div></section>

<section class="pd-section" style="background:var(--paper-raised);"><div class="wrap two-col">
  <div>
    <h2>Applications</h2>
    <ul class="feature-list">%(app_items)s</ul>
  </div>
  <div>
    <h2>Key Features</h2>
    <ul class="feature-list">%(feat_items)s</ul>
  </div>
</div></section>

<section class="pd-section"><div class="wrap">
  <h2>Technical Information</h2>
  <p class="body-copy" style="margin-bottom:18px;">Exact specifications for the %(product)s are confirmed with the AWFTEX engineering team against your site and application. Indicative fields are listed below.</p>
  <table class="spec-table">%(spec_rows)s</table>
</div></section>

<section class="pd-section" style="background:var(--paper-raised);"><div class="wrap">
  <h2>Frequently Asked Questions</h2>
  %(faq_html)s
</div></section>

<section class="pd-section"><div class="wrap">
  <h2>Related Products</h2>
  <div class="related-grid">%(related_html)s</div>
</div></section>

<section class="pd-section" style="border-top:1px solid var(--line);"><div class="wrap">
  <div class="enquiry-panel">
    <h2>Enquire about the %(product)s</h2>
    <p>Share a few details and an AWFTEX engineer will follow up with configuration options and a formal quotation.</p>
    <form class="enquiry-form">
      <div class="form-row">
        <input type="text" placeholder="Full name" required>
        <input type="tel" placeholder="Phone number" required>
      </div>
      <div class="form-row">
        <input type="email" placeholder="Email address" required>
        <input type="text" placeholder="Company / Site name">
      </div>
      <div class="form-row full">
        <textarea placeholder="Tell us about your requirement — quantity, site, timeline">Enquiry about: %(product)s</textarea>
      </div>
      <button type="submit" class="cta">Submit Enquiry</button>
    </form>
  </div>
</div></section>
""" % dict(
                pmedia=illustration(product_seed, division_id=d['id'], product_name=product, tone="tone-card", w=900, h=720, alt=product, cls="product-media", label=g['tag']+"-SERIES"),
                product=product, dname=d['name'], gname=g['name'],
                p1=paras[0], p2=paras[1], p3=paras[2],
                industries=industries_html,
                app_items="".join('<li>%s</li>' % a for a in d['industries']),
                feat_items="".join('<li>%s</li>' % f for f in features),
                spec_rows=spec_rows, faq_html=faq_html, related_html=related_html,
                wa=wa_link(wa_text), waicon=icon('whatsapp')
            )
            body += footer(prefix)
            extra_head = '<script type="application/ld+json">%s</script><script type="application/ld+json">%s</script>' % (jsonld, bc_jsonld)
            html = page(prefix, "%s | %s | AWFTEX" % (product, d['name']),
                        "%s — part of AWFTEX's %s range. Applications, technical information, FAQs and enquiry." % (product, d['name']),
                        body, extra_head, canonical_path=relpath, og_image=product_photo)
            with open(os.path.join(ROOT, 'solutions', d['id'], pslug + '.html'), 'w') as f:
                f.write(html)

# ---------------- CATEGORY PAGES ----------------
for d in DIVISIONS:
    prefix = "../../"
    os.makedirs(os.path.join(ROOT, 'solutions', d['id']), exist_ok=True)
    relpath = "solutions/%s/index.html" % d['id']
    register_url(relpath)
    crumbs = breadcrumb([("Home", prefix + "index.html"), ("Solutions", prefix + "solutions/index.html"), (d['name'], None)])
    count = sum(len(g['items']) for g in d['groups'])
    banner_seed = "awftex-div-%s" % d['id']
    banner_photo = None
    if d.get('pending'):
        groups_html = ""
    else:
        groups_html = ""
        for g in d['groups']:
            items_html = ""
            for p in g['items']:
                pseed = "awftex-%s-%s" % (d['id'], slug(p))
                thumb = icon_thumb(pick_icon(p, d['id'], g['tag']), d['id'], pseed)
                items_html += '<a class="product" href="%s.html"><span class="swatch">%s</span><span class="name">%s</span><span class="plus">+</span></a>' % (slug(p), thumb, p)
            groups_html += '<div class="group"><div class="group-head"><span class="tag mono">%s</span><h2>%s</h2></div><div class="product-grid">%s</div></div>' % (g['tag'], g['name'], items_html)
        guide_html = choose_guide_html(d)
        groups_html += guide_html
    faqs = [
        ("Does AWFTEX supply the full %s range, or individual products?" % d['name'],
         "Both. AWFTEX supplies individual product lines from the %s range as well as complete, coordinated systems where several product lines are engineered and installed together." % d['name']),
        ("Can AWFTEX handle installation and AMC for %s?" % d['name'],
         "Yes — installation, commissioning and annual maintenance contracts (AMC) can be scoped alongside supply. Share your requirement through the enquiry form."),
        ("Which industries does AWFTEX's %s division typically serve?" % d['name'],
         ("AWFTEX's %s division is typically specified for %s, among other facility types with similar requirements." % (d['name'], ', '.join(d['industries'][:4]).lower())) if d['industries'] else "This division's typical industries are confirmed once scope is finalised with AWFTEX."),
    ]
    faq_html = "".join('<details class="faq-item"><summary>%s</summary><div class="a">%s</div></details>' % (q, a) for q, a in faqs)
    industries_html = "".join('<div class="industry-tile">%s<span>%s</span></div>' % (icon(INDUSTRY_ICON.get(i, 'building2')), i) for i in d['industries'])
    body = header(prefix) + crumbs + """
<section class="wrap">
  <div class="cat-banner">
    %(banner)s
    <div class="cat-banner-inner">
      <div><div class="badge">%(icon)s</div><h1>%(name)s</h1><div class="sub">%(desc)s</div></div>
      <div class="count-badge"><b>%(count)s</b>%(count_label)s</div>
    </div>
  </div>
  <p class="body-copy" style="max-width:80ch;margin-bottom:36px;">%(seo)s AWFTEX scopes the %(name)s range as full engineering-to-commissioning projects or as individual product supply, depending on what your site and timeline call for — the same catalog depth you'd expect from a specialist vendor in this field alone, backed by a single point of technical contact.</p>
  %(groups)s
</section>

%(industries_section)s

<section class="pd-section"><div class="wrap">
  <h2>Frequently Asked Questions — %(name)s</h2>
  %(faq_html)s
</div></section>
""" % dict(banner=illustration(banner_seed, division_id=d['id'], tone="tone-hero", w=1600, h=700, alt=d['name'], cls="cat-banner-media", label=d['name']),
           icon=icon(d['icon']), name=d['name'], desc=d['desc'], seo=d.get('seo', ''),
           count=(count if not d.get('pending') else '—'),
           count_label=('PRODUCTS' if not d.get('pending') else 'PENDING'), groups=groups_html,
           faq_html=faq_html,
           industries_section=('<section class="section-head wrap tight"><div class="eyebrow"><span class="rule"></span>INDUSTRIES SERVED</div><h2>Where the %s range gets deployed</h2></section><div class="wrap"><div class="industry-strip">%s</div></div>' % (d['name'], industries_html)) if d['industries'] else '')
    body += footer(prefix)
    html = page(prefix, "%s | AWFTEX Solutions" % d['name'],
                "%s — %s" % (d['name'], d['tagline']), body, canonical_path=relpath, og_image=banner_photo)
    with open(os.path.join(ROOT, 'solutions', d['id'], 'index.html'), 'w') as f:
        f.write(html)

# ---------------- SOLUTIONS OVERVIEW ----------------
prefix = "../"
register_url("solutions/index.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Solutions", None)])
cards = ""
for d in DIVISIONS:
    count = sum(len(g['items']) for g in d['groups'])
    card_seed = "awftex-div-%s" % d['id']
    cards += """<a class="sol-card" href="%(id)s/index.html">
      <div class="sol-media">%(media)s<div class="icon-wrap">%(icon)s</div><div class="tag">SOLUTION</div></div>
      <div class="sol-body"><h3>%(name)s</h3><p>%(tagline)s</p>
      <div class="sol-meta"><span class="count">%(count_label)s</span><span class="go">View range %(arrow)s</span></div></div>
    </a>""" % dict(id=d['id'], media=illustration(card_seed, division_id=d['id'], tone="tone-card", w=640, h=400, alt=d['name'], cls="sol-media-img", label=d['name']),
                   icon=icon(d['icon']), name=d['name'], tagline=d['tagline'], arrow=icon('arrow'),
                   count_label=('SCOPE IN PROGRESS' if d.get('pending') else '%s PRODUCT LINES' % count))
body = header(prefix) + crumbs + """
<section class="section-head wrap">
  <div class="eyebrow"><span class="rule"></span>ALL SOLUTIONS</div>
  <h2>Nine solution divisions. One catalog.</h2>
  <p>Each division opens into its full product architecture — categories, individual product lines and technical detail. Browse the full AWFTEX engineering catalog below, or tell us the problem and we'll point you to the right division.</p>
</section>
<div class="wrap"><div class="sol-grid">%s</div></div>
""" % cards
body += footer(prefix)
html = page(prefix, "All Solutions | AWFTEX", "Browse all nine AWFTEX solution divisions and their full product architecture — fire safety, MEP, industrial, dairy, water, solar, security, air and infrastructure.", body, canonical_path="solutions/index.html")
with open(os.path.join(ROOT, 'solutions', 'index.html'), 'w') as f:
    f.write(html)

# ---------------- HOME PAGE ----------------
prefix = ""
register_url("index.html")
total_products = sum(sum(len(g['items']) for g in d['groups']) for d in DIVISIONS)
home_cards = ""
for d in DIVISIONS:
    count = sum(len(g['items']) for g in d['groups'])
    card_seed = "awftex-div-%s" % d['id']
    home_cards += """<a class="sol-card" href="solutions/%(id)s/index.html">
      <div class="sol-media">%(media)s<div class="icon-wrap">%(icon)s</div><div class="tag">SOLUTION</div></div>
      <div class="sol-body"><h3>%(name)s</h3><p>%(tagline)s</p>
      <div class="sol-meta"><span class="count">%(count_label)s</span><span class="go">View range %(arrow)s</span></div></div>
    </a>""" % dict(id=d['id'], media=illustration(card_seed, division_id=d['id'], tone="tone-card", w=640, h=400, alt=d['name'], label=d['name']),
                   icon=icon(d['icon']), name=d['name'], tagline=d['tagline'], arrow=icon('arrow'),
                   count_label=('SCOPE IN PROGRESS' if d.get('pending') else '%s PRODUCT LINES' % count))

schem_tiles = "".join('<div class="schem-tile">%s<span>%s</span></div>' % (icon(d['icon']), d['name']) for d in DIVISIONS)

all_industries = []
for d in DIVISIONS:
    for i in d['industries']:
        if i not in all_industries:
            all_industries.append(i)
marquee_items = "".join('<span>%s</span>' % i for i in all_industries)
marquee_html = '<div class="marquee">%s%s</div>' % (marquee_items, marquee_items)

process_steps = [
    ("01", "Share the requirement", "Tell us the site, the scope, or just the problem you're solving — a single product, a full system, or a multi-division project."),
    ("02", "Engineering review", "An AWFTEX engineer reviews layout, load, compliance and integration points before recommending a configuration."),
    ("03", "Supply & installation", "Equipment is sourced or fabricated, delivered to site and installed by AWFTEX or a coordinated installation partner."),
    ("04", "Commissioning & handover", "Systems are commissioned, tested and handed over with the documentation your facility needs to operate them."),
]
process_html = "".join('<div class="process-card"><span class="pnum mono">%s</span><h3>%s</h3><p>%s</p></div>' % (n, t, p) for n, t, p in process_steps)

value_cards = [
    ('target', 'One partner, nine disciplines', 'Fire safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems specified and delivered by a single technical partner instead of nine separate vendors.'),
    ('layers', 'Full product architecture', 'Every division is built out to category and individual product-line depth — the same catalog resolution you would expect from a specialist vendor in that field alone.'),
    ('wrench', 'Supply through commissioning', 'Scope runs from product supply to installation and commissioning, coordinated as one project rather than handed off between vendors.'),
    ('compass', 'Engineering-first approach', 'Configuration is confirmed against your site, load and layout before anything is quoted — not the other way around.'),
    ('shield', 'Built for industrial duty', 'Systems are selected and specified for continuous industrial and commercial operation, not consumer-grade equivalents.'),
    ('spark', 'Responsive technical contact', "One enquiry routes to the right division's engineering team — no navigating multiple vendor contacts for a multi-system project."),
]
value_html = "".join('<div class="value-card"><div class="vicon">%s</div><h3>%s</h3><p>%s</p></div>' % (icon(ic), t, p) for ic, t, p in value_cards)

hero_seed = "awftex-hero-main"
HERO_PHOTO = "https://images.pexels.com/photos/2425129/pexels-photo-2425129.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
body = header(prefix) + """
<section class="hero">
  <div class="hero-bg"><div class="photo-media tone-hero"><img src="%(herophoto)s" alt="AWFTEX engineering facility" loading="eager" width="1920" height="1080"></div></div>
  <div class="hero-aurora" aria-hidden="true">
    <span class="aurora-orb orb-a"></span>
    <span class="aurora-orb orb-b"></span>
    <span class="aurora-orb orb-c"></span>
  </div>
  <div class="hero-grid-overlay"></div>
  <div class="hero-scanline" aria-hidden="true"></div>
  <div class="wrap hero-inner">
    <div>
      <div class="eyebrow on-dark"><span class="rule"></span>ENGINEERING SOLUTIONS PLATFORM</div>
      <h1>One partner for <span>every system</span> your facility runs on.</h1>
      <p class="lead">AWFTEX designs, supplies and installs across fire &amp; life safety, MEP, industrial engineering, dairy &amp; food processing, water treatment, solar, security, environmental and infrastructure systems — a single technical partner instead of nine different vendors.</p>
      <div class="hero-ctas">
        <a href="#solutions" class="cta">Explore Solutions %(arrow)s</a>
        <a href="company/contact.html" class="cta ghost on-dark">Talk to an Engineer</a>
      </div>
    </div>
    <div class="hero-side">
      <div class="schem-card">
        <div class="schem-glow" aria-hidden="true"></div>
        <h4>SOLUTION DIVISIONS</h4>
        <div class="schem-tiles">%(schem)s</div>
      </div>
    </div>
  </div>
  <div class="wrap"><div class="stat-strip">
    <div class="stat"><div class="num">09</div><div class="lbl">Solution Divisions</div></div>
    <div class="stat"><div class="num">%(total)s+</div><div class="lbl">Product Lines Cataloged</div></div>
    <div class="stat"><div class="num">01</div><div class="lbl">Single Technical Partner</div></div>
  </div></div>
</section>

<div class="marquee-wrap"><div class="wrap">%(marquee)s</div></div>

<section class="section-head wrap" id="solutions">
  <div class="eyebrow"><span class="rule"></span>SOLUTIONS OVERVIEW</div>
  <h2>Nine solution divisions. One catalog.</h2>
  <p>Each division below opens into its full product architecture — categories, individual product lines and technical detail — the same depth you'd expect from a dedicated specialist in that field.</p>
</section>
<div class="wrap"><div class="sol-grid">%(cards)s</div></div>

<section class="section-head wrap tight">
  <div class="eyebrow"><span class="rule"></span>HOW IT WORKS</div>
  <h2>From enquiry to commissioned system.</h2>
  <p>A single process across every division — whether it's one product line or a multi-system project spanning fire safety, MEP and power.</p>
</section>
<div class="wrap"><div class="process-grid">%(process)s</div></div>

<section class="section-head wrap tight">
  <div class="eyebrow"><span class="rule"></span>WHY AWFTEX</div>
  <h2>Engineering breadth without losing technical depth.</h2>
  <p>Fragmenting a facility's systems across nine vendors means nine relationships, nine timelines and nine points of failure. AWFTEX consolidates that into one.</p>
</section>
<div class="wrap"><div class="value-grid3">%(values)s</div></div>

""" % dict(total=total_products, schem=schem_tiles, cards=home_cards, marquee=marquee_html, process=process_html,
           values=value_html, arrow=icon('arrow'), herophoto=HERO_PHOTO)
body += footer(prefix)
org_jsonld = json.dumps({
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": BRAND['legal_name'],
    "alternateName": "AWFTEX",
    "url": SITE_URL + "/",
    "logo": SITE_URL + "/assets/favicon-512.png",
    "slogan": BRAND['tagline'],
    "email": BRAND['email'],
    "telephone": BRAND['phone_tel'],
    "address": [
        {"@type": "PostalAddress", "streetAddress": "E-324, Jaitpur Extension Part II", "addressLocality": "New Delhi", "postalCode": "110044", "addressCountry": "IN"},
        {"@type": "PostalAddress", "streetAddress": "Plot 01, Mindkali, Budhana", "addressLocality": "Muzaffarnagar", "addressRegion": "Uttar Pradesh", "postalCode": "251309", "addressCountry": "IN"},
    ],
    "sameAs": []
})
local_jsonld = json.dumps({
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": BRAND['legal_name'],
    "image": SITE_URL + "/assets/logo.png",
    "telephone": BRAND['phone_tel'],
    "email": BRAND['email'],
    "address": {"@type": "PostalAddress", "streetAddress": "E-324, Jaitpur Extension Part II", "addressLocality": "New Delhi", "postalCode": "110044", "addressCountry": "IN"},
    "priceRange": "$$"
})
html = page(prefix, "AWFTEX | Engineering Solutions Platform",
            "AWFTEX is a multi-solution engineering platform covering fire & life safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems.",
            body, extra_head='<script type="application/ld+json">%s</script><script type="application/ld+json">%s</script>' % (org_jsonld, local_jsonld),
            canonical_path="index.html", og_image=HERO_PHOTO)
with open(os.path.join(ROOT, 'index.html'), 'w') as f:
    f.write(html)

# ---------------- ABOUT ----------------
prefix = "../"
register_url("company/about.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Company", None)])
about_seed = "awftex-about"
timeline_items = [
    ("Scope", "Engineering scope definition", "Every engagement starts with understanding the site — building type, load profile, compliance requirements and which of AWFTEX's nine solution divisions the project touches."),
    ("Design", "Product & system selection", "Product lines are matched to the requirement, whether that's a single fire extinguisher order or a coordinated MEP + fire + security fit-out."),
    ("Deliver", "Supply, fabrication & installation", "Equipment is supplied or fabricated and installed by AWFTEX or a coordinated installation team, sequenced against the rest of the project."),
    ("Support", "Commissioning & after-sales", "Systems are tested, commissioned and handed over, with AMC and ongoing technical support available where the facility needs it."),
]
tl_html = "".join('<div class="timeline-item"><div class="timeline-dot">%s</div><div class="timeline-body"><h3>%s</h3><p>%s</p></div></div>' % (n, t, p) for n, t, p in timeline_items)
about_values = [
    ('layers', 'Breadth with depth', 'Nine engineering disciplines — fire & life safety, MEP, industrial, dairy & food processing, water & wastewater, solar & energy, security & surveillance, air & environmental, and infrastructure — each built out to full product-line depth rather than a single catch-all page.'),
    ('compass', 'One technical partner', 'Instead of coordinating separate vendors for each system on a project, a facility owner or project team works with a single AWFTEX point of contact across every discipline the project touches.'),
    ('wrench', 'Supply through commissioning', 'AWFTEX scopes work from product supply through installation and commissioning, so systems arrive coordinated rather than assembled from disconnected vendor deliveries.'),
]
about_values_html = "".join('<div class="value-card"><div class="vicon">%s</div><h3>%s</h3><p>%s</p></div>' % (icon(ic), t, p) for ic, t, p in about_values)
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>About AWFTEX</h1>
    <p>AWFTEX Industries operates as a multi-solution engineering platform — one technical partner across fire &amp; life safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems.</p>
  </div>
</section>

<section class="content-block wrap">
  <h2>A single engineering partner, nine disciplines deep</h2>
  <p class="body-copy">Most facilities end up managing fire safety, electrical and HVAC, water treatment, security and other building systems as separate vendor relationships — each with its own point of contact, its own quoting process and its own installation schedule. AWFTEX consolidates that into a single technical partner that can scope, supply and commission across all nine of these disciplines.</p>
  <p class="body-copy">The catalog reflects that: every solution division on this site is built out to individual product-line depth, from portable fire extinguishers to complete turnkey dairy plants, so a project team can size a single product or an entire multi-system scope without switching vendors mid-project.</p>
  <p class="body-copy">AWFTEX operates from an office in New Delhi and a manufacturing / fabrication unit in Budhana, Muzaffarnagar, Uttar Pradesh — supporting both engineering coordination and equipment fabrication under one operation.</p>
</section>

<section class="content-block wrap">
  <h2>What AWFTEX brings to a project</h2>
  <div class="value-grid">%(values)s</div>
</section>

<section class="content-block wrap">
  <h2>How an AWFTEX engagement runs</h2>
  <p class="body-copy">The process is the same whether the scope is a single product line or a coordinated multi-division project.</p>
  <div class="timeline">%(timeline)s</div>
</section>

<section class="content-block wrap" style="padding-bottom:60px;">
  <h2>Where to find AWFTEX</h2>
  <div class="loc-grid">
    <div class="loc-card"><h3>%(pinicon)s Registered / Office Address</h3><p>%(office)s</p></div>
    <div class="loc-card"><h3>%(pinicon)s Manufacturing Unit</h3><p>%(plant)s</p></div>
  </div>
</section>
""" % dict(media=illustration(about_seed, division_id='infra', tone="tone-hero", w=1600, h=700, alt="About AWFTEX", cls="page-hero-media", label="AWFTEX"),
           values=about_values_html, timeline=tl_html, pinicon=icon('pin'), office=BRAND['office_address'], plant=BRAND['plant_address'])
body += footer(prefix)
html = page(prefix, "About AWFTEX | Engineering Solutions Platform",
            "About AWFTEX Industries — a multi-solution engineering platform covering fire safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems.",
            body, canonical_path="company/about.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'about.html'), 'w') as f:
    f.write(html)

# ---------------- WHY AWFTEX ----------------
prefix = "../"
register_url("company/why-awftex.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Why AWFTEX", None)])
why_seed = "awftex-why"
why_cards = [
    ('target', 'Single point of technical accountability', 'When one vendor supplies your fire alarm system and another handles the electrical panel it needs to interface with, integration issues surface late and get argued over between vendors. A single AWFTEX scope removes that seam.'),
    ('layers', 'Full catalog depth per discipline', "Each of AWFTEX's nine divisions is built out to category and individual product-line depth, not a generic services page. That means the same technical resolution you'd expect from hiring a specialist in fire safety, MEP, water treatment or any other discipline individually."),
    ('wrench', 'Supply, fabrication & installation under one roof', "With an in-house manufacturing / fabrication unit alongside engineering and installation teams, AWFTEX can move a project from specification to a commissioned system without handing it between separate supply and installation vendors."),
    ('compass', 'Configuration before quotation', "AWFTEX confirms layout, load, compliance and integration requirements against your site before finalising a configuration — rather than quoting a generic product and adjusting later."),
    ('shield', 'Industrial-duty specification', "Products and systems are specified for continuous industrial and commercial duty cycles, sized to the facility rather than offered as one-size-fits-all equivalents."),
    ('clock', 'Coordinated project timelines', "On multi-division projects — say, MEP plus fire safety plus security for a new facility — sequencing across disciplines is coordinated by one team instead of negotiated between separate vendors' schedules."),
]
why_html = "".join('<div class="value-card"><div class="vicon">%s</div><h3>%s</h3><p>%s</p></div>' % (icon(ic), t, p) for ic, t, p in why_cards)
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>Why AWFTEX</h1>
    <p>A single technical partner across nine engineering disciplines, instead of coordinating separate vendors for each system your facility depends on.</p>
  </div>
</section>

<section class="content-block wrap">
  <h2>The cost of vendor fragmentation</h2>
  <p class="body-copy">A typical industrial or commercial facility touches fire &amp; life safety, HVAC and electrical (MEP), water treatment, security, and often solar and environmental systems as well. Sourced separately, that's five to nine vendor relationships — each with its own quoting cycle, its own installation crew, and its own idea of who owns an integration problem when two systems need to talk to each other.</p>
  <p class="body-copy">AWFTEX exists to remove that fragmentation. One enquiry, routed to the right division's engineering team, can scale from a single product line to a full multi-system project — without the facility owner having to manage the seams between vendors themselves.</p>
</section>

<section class="content-block wrap" style="padding-bottom:60px;">
  <h2>What that looks like in practice</h2>
  <div class="value-grid">%(cards)s</div>
</section>
""" % dict(media=illustration(why_seed, division_id='mep', tone="tone-hero", w=1600, h=700, alt="Why AWFTEX", cls="page-hero-media", label="WHY AWFTEX"), cards=why_html)
body += footer(prefix)
html = page(prefix, "Why AWFTEX | Single Partner Across Nine Engineering Disciplines",
            "Why choose AWFTEX — a single technical partner across fire safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure systems, instead of nine separate vendors.",
            body, canonical_path="company/why-awftex.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'why-awftex.html'), 'w') as f:
    f.write(html)

# ---------------- INDUSTRIES ----------------
prefix = "../"
register_url("company/industries.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Industries", None)])
industries_seed = "awftex-industries"
industries_desc = {
 'Manufacturing plants': "Fire safety, MEP, power and air-quality systems sized for continuous production environments and shift-based operation.",
 'Warehouses & logistics parks': "Fire detection and suppression, security and lighting scoped for large-footprint, high-racking storage facilities.",
 'Commercial high-rises': "Coordinated fire, MEP and security systems designed to code for vertical, multi-tenant occupancy.",
 'Data centres': "Precision fire suppression, power redundancy and access-controlled security for mission-critical environments.",
 'Hospitals': "Life-safety systems, HVAC and water treatment engineered for continuous, compliance-critical healthcare operation.",
 'Hospitality': "Fire safety, MEP and security integrated for guest-facing buildings without compromising service experience.",
 'Commercial buildings': "MEP, fire and security systems coordinated across office and mixed-use developments.",
 'Industrial facilities': "Full-spectrum systems from process equipment to fire safety, sized for heavy operational duty.",
 'IT parks & campuses': "Power, HVAC, fire and security systems scoped across multi-building technology campuses.",
 'Retail & malls': "Fire, MEP and security systems designed around high footfall and extended operating hours.",
 'Manufacturing': "Custom machinery, process equipment and automation aligned to your production line.",
 'Process industries': "Engineered tanks, vessels and material handling systems built for continuous process operation.",
 'Warehousing & logistics': "Storage, conveyor and material handling systems sized to throughput and layout.",
 'Heavy engineering': "Fabrication and plant equipment engineered for heavy-duty industrial applications.",
 'Food & beverage plants': "Process equipment and water treatment systems that meet food-grade operating requirements.",
 'Chemical plants': "Tanks, vessels and effluent treatment systems engineered for chemical-process compliance.",
 'Dairy processing units': "Chilling, pasteurization and processing lines sized from a single unit to a full plant.",
 'Milk cooperatives': "Bulk milk coolers and chilling infrastructure for aggregation and cooperative operations.",
 'Food manufacturing': "Processing and storage equipment engineered for hygienic, continuous food production.",
 'Cold chain & logistics': "Chilling and storage systems that preserve product integrity across the cold chain.",
 'Retail dairy': "Vending and storage equipment sized for retail-scale dairy operations.",
 'Hospitality & catering': "Processing and storage equipment scaled for hospitality and catering kitchens.",
 'Municipal utilities': "Water and wastewater treatment infrastructure engineered for municipal-scale demand.",
 'Pharmaceutical & chemical plants': "Water treatment and effluent systems engineered to pharma and chemical compliance standards.",
 'Industrial rooftops': "Rooftop solar systems sized to your site's structural load and roof profile.",
 'Institutional campuses': "Solar, energy management and MEP systems scoped across educational and institutional campuses.",
 'Agricultural sites': "Solar generation systems designed for open-land and agricultural installations.",
 'Residential townships': "Solar, security and MEP systems scoped for multi-unit residential developments.",
 'Residential complexes': "Security, access control and surveillance systems for gated residential communities.",
 'Retail': "Security and surveillance systems designed around customer-facing retail environments.",
 'Educational institutions': "Security, fire safety and MEP systems scoped for campus-wide educational facilities.",
 'Warehousing': "Air quality and dust control systems for large-footprint storage and handling facilities.",
 'Workshops & fabrication units': "Fume extraction and ventilation systems for active fabrication and workshop environments.",
 'Pharmaceutical facilities': "Clean-air and filtration systems engineered to pharmaceutical-grade air quality requirements.",
}
seen = set()
industry_cards = ""
for d in DIVISIONS:
    for i in d['industries']:
        if i in seen:
            continue
        seen.add(i)
        desc = industries_desc.get(i, "Systems scoped and specified against this facility type's operational requirements.")
        industry_cards += '<div class="value-card"><div class="vicon">%s</div><h3>%s</h3><p>%s</p></div>' % (icon(INDUSTRY_ICON.get(i, 'building2')), i, desc)
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>Industries We Serve</h1>
    <p>AWFTEX's nine solution divisions are built for the industries that actually need them — from manufacturing plants and data centres to dairy processing units and municipal utilities.</p>
  </div>
</section>

<section class="content-block wrap">
  <h2>Facility types across every division</h2>
  <p class="body-copy">Each solution division is specified against real operating conditions rather than offered as one generic package. Below is the combined set of industries AWFTEX's divisions serve — the relevant division page has the full product architecture for each.</p>
</section>
<section class="content-block wrap" style="padding-top:0;padding-bottom:60px;">
  <div class="value-grid">%(cards)s</div>
</section>
""" % dict(media=illustration(industries_seed, division_id='industrial', tone="tone-hero", w=1600, h=700, alt="Industries AWFTEX Serves", cls="page-hero-media", label="INDUSTRIES"), cards=industry_cards)
body += footer(prefix)
html = page(prefix, "Industries We Serve | AWFTEX",
            "The industries AWFTEX serves across fire safety, MEP, industrial, dairy, water, solar, security, environmental and infrastructure engineering — manufacturing, healthcare, data centres, dairy, hospitality and more.",
            body, canonical_path="company/industries.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'industries.html'), 'w') as f:
    f.write(html)

# ---------------- PROJECTS ----------------
prefix = "../"
register_url("company/projects.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Projects", None)])
projects_seed = "awftex-projects"
scope_examples = [
    ('fire', 'Fire & Life Safety scope', 'Detection and alarm, hydrant and sprinkler systems, suppression where required, and emergency evacuation infrastructure — specified, supplied and commissioned as one scope with compliance documentation handed over at close-out.',
     ['Site fire-risk assessment & system class','Detection, alarm and suppression supply','Hydrant / sprinkler installation','Testing, commissioning & handover documentation']),
    ('mep', 'MEP fit-out scope', 'HVAC, electrical distribution and plumbing coordinated across a building, sequenced with the fire safety and security scopes so systems that need to interface with each other are installed in the right order.',
     ['Load calculation & system sizing','Panel, cabling & ductwork installation','Coordination with fire & security scopes','Testing and building-services handover']),
    ('industrial', 'Industrial machinery & fabrication scope', 'Custom machinery, process equipment and fabrication work engineered around your specific line requirements, from single-machine orders to multi-unit plant equipment.',
     ['Process requirement & layout review','Fabrication drawing approval','Manufacture at the AWFTEX unit','Installation & commissioning on site']),
    ('dairy', 'Dairy plant scope', 'Processing, chilling and packaging equipment sized from a single bulk milk cooler to a complete turnkey dairy line, engineered around your collection volume and product mix.',
     ['Volume & product-mix assessment','Equipment selection & layout','Fabrication / procurement & installation','Hygiene testing & commissioning']),
    ('water', 'Water treatment scope', 'RO, DM or effluent treatment capacity sized against a site\'s actual water quality and demand, with commissioning tests confirming output before handover.',
     ['Feed water testing & demand assessment','Treatment train design','Skid fabrication & site installation','Output testing & compliance documentation']),
    ('solar', 'Solar EPC scope', 'Site and load assessment through mounting, installation, grid or hybrid integration and monitoring setup, delivered as a single EPC scope.',
     ['Site survey & structural assessment','System design & DISCOM liaison','Mounting, panel & inverter installation','Grid connection, testing & monitoring setup']),
    ('security', 'Security & surveillance scope', 'Camera, access control and perimeter systems planned around coverage priorities and integrated into a single monitored platform rather than installed piecemeal.',
     ['Coverage & risk-zone planning','Camera, NVR & access-control installation','Network & power infrastructure setup','System integration & handover training']),
    ('air', 'Air & environmental scope', 'Filtration, dust collection and ventilation systems sized against contaminant type and required air-change rate for the specific space.',
     ['Contaminant & air-quality assessment','System sizing & ducting design','Fabrication & installation','Performance testing & compliance sign-off']),
    ('infra', 'Infrastructure & building scope', 'Structural, envelope and finishing works sequenced alongside the MEP and fire safety scope on the same project, from new-build structure to occupied-site retrofit.',
     ['Structural / civil scope definition','Municipal approval coordination','Construction & envelope work','Sequencing with MEP & fire scopes']),
]
scope_html = ""
for dv, t, p, steps in scope_examples:
    dd = next(x for x in DIVISIONS if x['id'] == dv)
    seed = "awftex-scope-%s" % dv
    steps_html = "".join('<li>%s</li>' % s for s in steps)
    scope_html += ('<div class="scope-card"><div class="scope-media">%s</div><div class="scope-body">'
                   '<span class="tag mono">%s</span><h3>%s</h3><p>%s</p><ul>%s</ul>'
                   '<span class="illustrative-badge">%s Illustrative scope, not a specific project</span>'
                   '</div></div>') % (illustration(seed, division_id=dv, tone="tone-card", w=640, h=400, alt=t, label=dd['name']),
                                       dd['name'], t, p, steps_html, icon('compass'))
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>Projects</h1>
    <p>A showcase of AWFTEX's named, completed projects is being prepared — client names, project details and outcomes will be added here once confirmed. In the meantime, this page sets out the representative shape of a project in each of AWFTEX's nine divisions.</p>
  </div>
</section>

<section class="content-block wrap">
  <h2>What a project with AWFTEX typically looks like</h2>
  <p class="body-copy">Every card below describes the typical scope and sequence for that division — the kind of work AWFTEX takes on, and roughly how it runs from first enquiry to handover. None of this describes a specific named project, client or completed outcome; it's provided so you know what to expect structurally before you enquire. Real, named case studies will replace or sit alongside this section once AWFTEX confirms which projects can be published.</p>
</section>
<section class="content-block wrap" style="padding-top:0;padding-bottom:20px;">
  <div class="scope-grid">%(scope)s</div>
</section>
<section class="content-block wrap" style="padding-bottom:60px;">
  <h2>Multi-division projects</h2>
  <p class="body-copy">Many projects touch more than one division at once — a new warehouse, for instance, typically needs fire safety, MEP, security and sometimes solar and structural work coordinated on the same timeline. Where that's the case, AWFTEX sequences the relevant division scopes above into a single coordinated project plan with one point of technical contact, rather than requiring separate engagements per division.</p>
</section>
""" % dict(media=illustration(projects_seed, division_id='security', tone="tone-hero", w=1600, h=700, alt="AWFTEX Projects", cls="page-hero-media", label="PROJECTS"), scope=scope_html)
body += footer(prefix)
html = page(prefix, "Projects | AWFTEX",
            "The representative shape of an AWFTEX project across fire safety, MEP, industrial, dairy, water, solar, security, air and infrastructure — named case studies coming soon.",
            body, canonical_path="company/projects.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'projects.html'), 'w') as f:
    f.write(html)

# ---------------- INSIGHTS ----------------
prefix = "../"
register_url("company/insights.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Insights", None)])
insights_seed = "awftex-insights"
ARTICLES = [
    ("fire", "How to Choose the Right Fire Suppression System for Server Rooms",
     "Water-based suppression can damage the equipment it's meant to protect. Here's how clean agent, inert gas and other suppression types compare for data centre and server room risk profiles.",
     ["Why water and foam are usually ruled out first",
      "Clean agent systems (FM-200 / Novec-class agents): how they work and where they fit",
      "Inert gas suppression: the trade-offs against clean agent systems",
      "Detection strategy: why very early smoke detection matters more here than in open areas",
      "Room integrity: the often-overlooked factor that determines whether any suppression agent will actually hold concentration",
      "A practical checklist before you specify a system"],
     """Server rooms and data halls carry a specific kind of fire risk: the equipment inside is expensive, hard to replace quickly, and often more sensitive to the suppression method than to the fire itself. A conventional sprinkler head doing exactly what it's designed to do — dumping water on a fire — can write off a rack of servers that the fire itself hadn't yet reached. That's the starting point for almost every suppression decision in this category: the agent has to control the fire without creating a second, larger loss.

Clean agent systems, built around agents in the FM-200 / Novec class, are the most common answer for this reason. They extinguish by absorbing heat and interrupting the chemical combustion reaction, leave no residue, and don't conduct electricity, which is why they've become close to a default for occupied electrical and IT spaces. Cylinder banks are sized to the room volume, agent concentration is calculated to reach extinguishing levels within seconds, and the room needs to hold that concentration long enough to fully suppress the fire — which is where a lot of installations actually go wrong (more on that below).

Inert gas systems — blends of nitrogen, argon and sometimes CO2 — are the other common route. They work by reducing oxygen concentration in the room to a level that won't sustain combustion, rather than by chemical interruption. They're non-conductive and safe for occupied spaces at correctly calculated concentrations, and some specifiers prefer them because they leave literally nothing behind and involve no chemical agent. The trade-off is generally cylinder footprint: inert gas needs a larger volume of stored gas than a clean agent to achieve the same suppression effect, so the cylinder bank takes up more plant room space — a real constraint in facilities that are already tight on space.

Detection matters as much as the suppression agent choice. Because the goal in a server room is to suppress a fire before it does meaningful damage — not after a sprinkler-level fire has already developed — these systems are almost always paired with very early smoke detection (VESDA-type aspirating detection) rather than standard point smoke detectors. Aspirating detection continuously samples air through a pipe network and can flag a developing fire — sometimes an overheating component, before visible smoke — hours before a point detector would trigger. That head start is often what makes intervention with an isolated, contained fire possible instead of a full suppression discharge.

The factor that's easiest to get wrong on paper and expensive to get wrong on site is room integrity. A suppression agent that reaches the calculated concentration is only useful if the room actually holds that concentration for the required time — commonly ten minutes for clean agent systems. Cable penetrations, raised floor voids that aren't sealed, gaps around doors, and unsealed ceiling voids all let the agent leak out faster than the room was designed for, which can mean a fire re-ignites after what looked like a successful suppression event. A door fan integrity test — pressurising the room and measuring leakage — is the way this gets verified before a system is signed off, and it's a step that's sometimes skipped on smaller installations where it shouldn't be.

Before specifying, it's worth walking through: room volume and what's actually stored in it (some agents have restrictions or de-rated concentrations for spaces with specific equipment types), available plant room space for cylinders, whether the room can realistically achieve and maintain integrity, detection strategy and response plan, and — often forgotten — what happens to personnel access and any occupied-space concentration limits during a discharge. AWFTEX's engineering team runs through this assessment as part of scoping any server room or electrical room suppression project."""),
    ("water", "RO Plant vs DM Plant: Which Does Your Facility Actually Need?",
     "Reverse osmosis and demineralisation solve different water-quality problems. A quick guide to matching treatment technology to your process water requirements.",
     ["What RO actually removes, and what it doesn't",
      "What DM (demineralisation) is doing differently",
      "Why some facilities need both, in sequence",
      "Matching technology to end-use: boiler feed, process water, drinking water",
      "A quick way to think about which one you need"],
     """RO and DM get asked about almost interchangeably by facility teams, but they're solving different problems, and picking the wrong one for your end use either wastes capital or leaves you with water that still doesn't meet spec.

Reverse osmosis pushes feed water through a semi-permeable membrane under pressure, physically filtering out dissolved salts, most organics, bacteria and a wide range of contaminants down to a very fine level, but not all the way to zero. A well-run RO system typically rejects somewhere in the range of 95–99% of dissolved solids, which is more than sufficient for drinking water, most process water uses, and as a first stage before further polishing. What it doesn't do is get you to true demineralised — near-zero conductivity — water, because a small fraction of ions still pass through the membrane.

Demineralisation, done through ion exchange resin beds (or increasingly through electrodeionisation, EDI), is built specifically to strip out virtually all remaining dissolved ions, producing water with very low conductivity. This is the water quality that high-pressure boilers, certain pharmaceutical processes, laboratories and specific manufacturing processes (electronics cleaning, for instance) actually require — RO water alone isn't good enough for these, no matter how well the RO plant is run.

That's why many industrial facilities run RO followed by DM (or EDI) in sequence rather than choosing one over the other: RO handles the bulk of the dissolved solids and organic load cheaply, and DM does the fine polishing on a much smaller residual load than it would have to handle on raw feed water. Running DM resin directly on raw water is technically possible but exhausts the resin bed far faster and costs more in regeneration chemicals and resin replacement over time, so pairing the two is usually the more economical route for high-purity requirements, not just the more thorough one.

For end use, boiler feed water is the case most likely to need DM-grade quality — even fairly low mineral content can cause scaling on high-pressure boiler tubes over time, with real efficiency and safety consequences. General process water, cooling water and drinking water applications are very often satisfied by RO alone, particularly where the RO system is well-maintained and fed with reasonable-quality source water. Facilities with fluctuating or poor-quality source water (high TDS, hardness or specific contaminants) sometimes need RO just to get to a usable baseline before any further treatment, even for uses that wouldn't otherwise need this level of treatment.

A quick way to frame the decision: if you need water where salts and conductivity essentially don't matter for the end use — drinking, general process, cooling — start with an RO assessment against your actual feed water quality. If your end use is boiler feed, a sensitive manufacturing process, or any specification with a stated conductivity or resistivity number, budget for DM or RO+DM in sequence from the outset rather than adding it later once an RO-only system turns out to be insufficient. AWFTEX assesses feed water quality and end-use requirements together before recommending a treatment train, precisely because the two questions can't really be separated."""),
    ("mep", "Sizing an HVAC System for a Multi-Tenant Commercial Building",
     "Load calculation mistakes at the design stage are expensive to fix later. What actually goes into right-sizing AHUs, chillers and ductwork for mixed-occupancy buildings.",
     ["Why 'tonnage per square foot' rules of thumb break down in mixed occupancy",
      "The load calculation inputs that actually move the number",
      "Diversity factor: why the building doesn't need capacity for every tenant's peak at once",
      "Central plant vs distributed systems for multi-tenant buildings",
      "Designing for tenant churn, not just day-one occupancy"],
     """Rule-of-thumb sizing — a fixed tonnage per square foot — is a reasonable sanity check, but it breaks down fast in a mixed-occupancy building where one floor is open-plan offices, another is a server room or lab, and the ground floor is retail with very different footfall and equipment loads. Each of those spaces has a genuinely different cooling load per square foot, and sizing the whole building off a single blended number either oversizes the plant for most of the building or undersizes it for the tenants who actually need more.

A proper load calculation works from the inputs that actually drive the number: solar gain through glazing (orientation and glazing type matter, not just glazing area), occupant density (a call centre floor and a warehouse floor plate of the same size have very different occupant loads), equipment heat load per zone, ventilation air requirements per occupancy type, and building envelope performance. Skipping this and going straight to a blended tonnage figure is where a lot of comfort complaints and energy waste in commercial buildings trace back to, sometimes years after handover when it's much more expensive to fix.

Diversity factor is the concept that keeps a correctly-calculated building from being wildly oversized. It's very unlikely that every tenant hits their individual peak cooling demand at exactly the same moment — a north-facing office tenant's peak load timing differs from a west-facing retail tenant's, and not every floor runs at full occupancy simultaneously. Central plant is sized against a diversified total load, which is meaningfully lower than the sum of every individual zone's calculated peak. Getting the diversity factor wrong in either direction either leaves the plant undersized on the (rare) day everyone does peak together, or — more commonly — leaves it oversized and running inefficiently at partial load for most of its life.

Central plant (chillers serving building-wide air handling units) versus distributed systems (VRF or split systems per tenant) is a real decision point in multi-tenant buildings, and it's driven as much by metering, billing and tenant flexibility as by pure thermal efficiency. Central plant is typically more energy-efficient at the building level and easier to maintain centrally, but makes individual tenant energy billing harder and gives tenants less control over their own space. Distributed VRF systems solve the metering and control-autonomy problem and make it easier to bring a new tenant's fit-out online independently, at some cost in overall system efficiency and a more complex maintenance footprint (many more indoor and outdoor units to service instead of one central plant).

The other input that's easy to skip at design stage is tenant churn. A building designed tightly around its day-one tenant mix can be genuinely difficult to reconfigure when a future tenant needs a different load profile — a general office tenant leaving and a server-heavy fintech tenant moving in, for instance. Building in reasonable headroom and flexibility in ductwork routing, electrical capacity and zoning at design stage costs comparatively little upfront and avoids expensive retrofit work later. AWFTEX's MEP team runs load calculations at zone level rather than building-average level for exactly this reason, before recommending a central, distributed, or hybrid system architecture for a multi-tenant project."""),
    ("solar", "Rooftop Solar for Industrial Sites: What Determines Payback Period",
     "Roof structural capacity, shading, load profile and grid policy all move the payback math more than panel efficiency alone. A breakdown of what to check before committing to a system size.",
     ["Structural capacity: the check that happens before system size is even discussed",
      "Shading analysis: why a single chimney or water tank can matter more than panel efficiency",
      "Load profile match: why generation timing matters as much as generation volume",
      "Net metering vs gross metering vs hybrid: how your state's DISCOM policy changes the math",
      "O&M: the ongoing cost that's easy to underestimate at proposal stage"],
     """Panel efficiency numbers get most of the attention in solar conversations, but for an industrial rooftop project, four other factors move the actual payback period far more than the difference between one panel efficiency rating and another.

Structural capacity comes first, before system size is even seriously discussed. Industrial roofs vary hugely in live load capacity depending on age, roofing material and original design intent, and mounting structure plus panel weight adds meaningful dead load across the roof area. A structural assessment — sometimes requiring a structural engineer's sign-off, not just a visual inspection — determines the maximum system size the roof can actually carry before any generation or financial modelling is worth doing. Skipping this step and sizing a system purely against available roof area is a common and expensive mistake.

Shading analysis is the next filter, and it's more consequential than most people expect. A single rooftop obstruction — a water tank, a chimney, an adjacent taller structure, or even a neighbouring building's shadow at certain times of day — can disproportionately cut generation from an entire string of panels, not just the shaded panels themselves, depending on the inverter and stringing configuration. A proper shading study across the day and across seasons (shading patterns shift meaningfully between summer and winter sun angles) often changes both the recommended system size and the physical layout more than a simple "how much roof area is available" calculation would suggest.

Load profile match matters as much as total generation volume for payback economics, particularly for facilities without net metering or with unfavourable net metering terms. A facility that runs a single day shift and is largely idle at night gets a very different value from a solar system than a facility running three shifts, because solar generation is concentrated in daylight hours and self-consumption during generation hours is generally worth more than exported units credited at a lower feed-in rate. Sizing a system against actual hourly load data, not just monthly total consumption, is what makes this comparison meaningful.

Net metering, gross metering and hybrid connection policies differ by state DISCOM and change the payback math substantially. Net metering (where exported units offset consumption at retail rate) is generally the most favourable structure for a facility with good self-consumption; gross metering (where all generation is sold at a separate, often lower, tariff) changes the calculation considerably, and some states apply different rules above certain system size thresholds. This is genuinely one of the first things to confirm for a specific site, because the same system size can have a meaningfully different payback period purely based on which policy applies.

Finally, operations and maintenance cost is easy to underweight at proposal stage because it doesn't show up as a large single number — but panel soiling, connector and inverter servicing, and monitoring all have a real ongoing cost, and generation quietly degrades if cleaning and monitoring aren't kept up. A system that looks excellent on a day-one payback spreadsheet can underperform its projected numbers for years if O&M access wasn't planned into the original layout. AWFTEX scopes structural assessment, shading study and load-profile matching together before proposing a system size, for exactly this reason."""),
    ("dairy", "Cold Chain Basics: Bulk Milk Coolers vs Milk Chilling Systems",
     "Both slow down spoilage, but they're specified differently depending on collection volume and frequency. Where each fits in a dairy cold chain.",
     ["What a bulk milk cooler is actually built for",
      "Where a milk chilling system differs, and when it's the better fit",
      "Collection frequency: the variable that decides between the two",
      "Cooling rate matters as much as final temperature",
      "Sizing for growth without overspending on day-one capacity"],
     """Bulk milk coolers and milk chilling systems both exist to slow bacterial growth in raw milk between collection and processing or dispatch, but they're specified around different operating patterns, and picking based on collection volume alone without considering frequency and growth plans is a common sizing mistake.

A bulk milk cooler (BMC) is built around a batch model: milk is collected, generally from multiple small suppliers or a village-level collection point, into an insulated vat and cooled down to storage temperature (typically around 4°C) within a defined window, then held at that temperature until the next collection vehicle picks it up. BMCs are sized by batch volume and by how many collection cycles they need to handle per day — a twice-daily collection pattern needs a different specification than a once-daily pattern even at the same total daily volume, because the cooler needs to bring each fresh batch down to temperature fast enough that it doesn't compromise milk already held from the previous batch.

Milk chilling systems are generally the answer at larger, more continuous-flow operations — a dairy processing plant's own intake, for instance, where milk arrives more continuously through the day from multiple routes or larger tankers rather than in the batch pattern a village-level BMC is designed around. These systems are typically integrated with plate heat exchangers for faster, continuous cooling rather than the tank-based batch cooling a BMC uses, and are sized against throughput rate (litres per hour) rather than batch volume.

Collection frequency and pattern is really the variable that decides between the two more than raw volume does. A collection centre handling a moderate volume across two collection cycles a day is well served by a correctly sized BMC. A processing facility receiving continuous tanker inflow through the day, even at a similar total daily volume, is usually better served by a chilling system built for continuous throughput rather than a large batch tank trying to accommodate near-constant fresh milk inflow.

Cooling rate matters as much as the final holding temperature, and it's the detail that gets underweighted when equipment is bought purely against a temperature spec. Milk that reaches 4°C slowly has already allowed more bacterial growth in the time it took to get there than milk cooled rapidly to the same final temperature — so a BMC or chilling system's rated cooling time (how fast it brings a fresh batch down, not just what temperature it eventually reaches) is a genuinely important spec to check, not just the holding temperature number on the datasheet.

On sizing for growth: collection volumes for a dairy business tend to grow, sometimes quickly if new supplier routes come online, and undersizing a BMC against only current-day volume is a common false economy — the cost of stepping up to the next capacity tier later, including re-plumbing and potential downtime, is usually higher than sizing in reasonable headroom from the start. AWFTEX sizes both collection volume and reasonable growth headroom into the specification when scoping bulk milk coolers and chilling systems, rather than quoting purely against today's numbers."""),
    ("security", "CCTV Coverage Planning: Camera Count Isn't the Right Metric",
     "More cameras don't automatically mean better coverage. Placement, field of view overlap and NVR storage planning matter more than raw camera count.",
     ["Why 'how many cameras do I need' is the wrong first question",
      "Coverage priorities: not every part of a site needs the same camera density",
      "Field of view overlap and blind spots — the detail generic quotes skip",
      "Storage planning: the constraint that gets discovered too late",
      "IP vs analog, and when the choice actually matters"],
     """"How many cameras do I need?" is the question almost every CCTV enquiry starts with, and it's genuinely the wrong first question — camera count is an output of a coverage plan, not an input to one, and two sites of the same size can need very different camera counts depending on layout and risk priorities.

The right starting point is coverage priorities: entry and exit points, perimeter boundaries, high-value storage or cash-handling areas, and blind corners created by the site's own layout generally need denser, more deliberately placed coverage than open floor space that a single well-positioned camera can cover adequately. A warehouse with one main entrance and a fenced perimeter has a very different coverage plan from an open retail floor with multiple customer entry points, even if both sites are a similar physical size — treating them the same and pricing purely per square foot of area misses this entirely.

Field of view overlap and blind spots are the details a generic "cameras per square foot" quote tends to skip, and they matter more than they sound like they would. A layout with technically enough cameras to "cover" a space can still leave usable blind spots at doorways, behind pillars, or at the exact boundary between two cameras' fields of view — spots that don't show up on a floor plan sketch but do show up in actual footage review after an incident, which is usually the worst possible time to discover a coverage gap. A proper site walk-through, ideally checking sightlines against the specific camera lens angles being proposed, catches this before installation rather than after.

Storage planning is the constraint that gets discovered too late, often well after installation. Required footage retention period — 30 days is common, but some facilities need longer for compliance or insurance reasons — combined with camera resolution and frame rate determines NVR/DVR storage capacity requirements, and this is a calculation that should happen before cameras are selected, not after. A system speced around impressive camera resolution without matching storage capacity either runs out of retention days faster than expected or forces a compromise on resolution or frame rate to stretch storage further than originally planned — neither of which is a decision you want made by running out of disk space rather than by deliberate choice.

IP versus analog camera systems is a real choice point, though it matters less than it used to as IP systems have become the more common default for new installations. IP cameras generally offer better resolution, easier scalability and remote access, and work over standard network infrastructure, which is an advantage where a site already has reasonable network cabling in place. Analog systems (including modern HD analog / TVI-type systems) can still make sense for retrofit situations with existing coaxial cabling already run through a building, where re-cabling for IP would be disruptive or costly relative to the upgrade in image quality gained. The right choice depends more on existing site infrastructure than on a blanket preference for one technology.

AWFTEX plans coverage priorities and storage requirements before proposing camera count or specific hardware, for the same reason a fire safety system is planned around risk zones rather than a blanket sprinkler-per-square-foot rule — coverage quality, not camera count, is what actually determines whether a system does its job when it's needed."""),
]
article_cards = ""
os.makedirs(os.path.join(ROOT, 'company', 'insights'), exist_ok=True)
for div_id, title, excerpt, outline, full_body in ARTICLES:
    d = next(x for x in DIVISIONS if x['id'] == div_id)
    art_slug = slug(title)[:60]
    art_seed = "awftex-article-%s" % slug(title)[:30]
    article_cards += """<div class="article-card">
      <div class="article-media">%(media)s</div>
      <div class="article-body">
        <span class="tag">%(dname)s</span>
        <h3>%(title)s</h3>
        <p>%(excerpt)s</p>
        <a class="readmore" href="insights/%(slug)s.html">Read article %(arrow)s</a>
      </div>
    </div>""" % dict(media=illustration(art_seed, division_id=div_id, tone="tone-card", w=640, h=400, alt=title, label=d['name']),
                     dname=d['name'], title=title, excerpt=excerpt, arrow=icon('arrow'), slug=art_slug)
    # ---- individual article page ----
    art_prefix = "../../"
    register_url("company/insights/%s.html" % art_slug)
    art_crumbs = breadcrumb([("Home", art_prefix + "index.html"), ("Insights", art_prefix + "company/insights.html"), (title, None)])
    outline_html = "".join("<li>%s</li>" % o for o in outline)
    paras_html = "".join("<p class=\"body-copy\">%s</p>" % p.strip() for p in full_body.strip().split("\n\n"))
    art_jsonld = json.dumps({
        "@context": "https://schema.org", "@type": "Article", "headline": title,
        "about": d['name'], "publisher": {"@type": "Organization", "name": BRAND['legal_name']},
        "description": excerpt,
    })
    art_body = header(art_prefix) + art_crumbs + """
<section class="page-hero">
  <div class="page-hero-inner">
    <span class="tag mono" style="color:#C9D6E4;">%(dname)s INSIGHTS</span>
    <h1>%(title)s</h1>
    <p>%(excerpt)s</p>
  </div>
</section>
<section class="content-block wrap" style="max-width:78ch;">
  <div class="note-panel" style="margin-bottom:32px;"><b>In this article:</b>
    <ul style="margin:10px 0 0 20px;padding:0;">%(outline)s</ul>
  </div>
  %(paras)s
  <div class="cta-inline" style="margin-top:40px;padding:28px 32px;background:var(--paper-raised);border:1px solid var(--line-soft);border-radius:var(--radius);">
    <p class="body-copy" style="margin-bottom:14px;"><b>Have a %(dname)s requirement AWFTEX can help scope?</b> Share your site details and an engineer will follow up with a considered recommendation, not a generic quote.</p>
    <a class="cta" href="%(prefix)scompany/contact.html">Talk to AWFTEX %(arrow)s</a>
  </div>
</section>
<script type="application/ld+json">%(jsonld)s</script>
""" % dict(dname=d['name'], title=title, excerpt=excerpt, outline=outline_html, paras=paras_html,
           prefix=art_prefix, arrow=icon('arrow'), jsonld=art_jsonld)
    art_body += footer(art_prefix)
    art_html = page(art_prefix, "%s | AWFTEX Insights" % title, excerpt, art_body,
                     canonical_path="company/insights/%s.html" % art_slug, og_image=None)
    with open(os.path.join(ROOT, 'company', 'insights', '%s.html' % art_slug), 'w') as f:
        f.write(art_html)
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>Insights &amp; Blog</h1>
    <p>Technical articles and engineering guides from AWFTEX's team, covering how to actually make the decisions that come up when specifying equipment across our nine solution divisions.</p>
  </div>
</section>

<section class="content-block wrap" style="padding-bottom:60px;">
  <h2>Latest articles</h2>
  <p class="body-copy">These are the questions AWFTEX's engineering team hears most often from project teams and facility owners. More will be added as new questions come up in the field.</p>
  <div class="article-grid">%(cards)s</div>
</section>
""" % dict(media=illustration(insights_seed, division_id='water', tone="tone-hero", w=1600, h=700, alt="AWFTEX Insights", cls="page-hero-media", label="INSIGHTS"), cards=article_cards)
body += footer(prefix)
html = page(prefix, "Insights & Blog | AWFTEX",
            "Technical articles and engineering guides from AWFTEX covering fire safety, MEP, water treatment, solar, dairy processing and security systems.",
            body, canonical_path="company/insights.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'insights.html'), 'w') as f:
    f.write(html)


# ---------------- CONTACT ----------------
prefix = "../"
register_url("company/contact.html")
crumbs = breadcrumb([("Home", prefix + "index.html"), ("Contact", None)])
contact_seed = "awftex-contact"
division_options = "".join('<option>%s</option>' % d['name'] for d in DIVISIONS)
contact_methods_html = """
  <a href="tel:%(tel)s">%(phoneicon)s %(phone)s</a>
  <a href="%(wa)s" target="_blank" rel="noopener">%(waicon)s WhatsApp: %(phone)s</a>
  <a href="mailto:%(email)s">%(mailicon)s %(email)s</a>
""" % dict(tel=BRAND['phone_tel'], phone=BRAND['phone_display'], email=BRAND['email'],
           wa=wa_link("Hi AWFTEX, I'd like to enquire about your engineering solutions."),
           phoneicon=icon('phone'), mailicon=icon('mail'), waicon=icon('whatsapp'))
contact_jsonld = json.dumps({
    "@context": "https://schema.org", "@type": "ContactPage",
    "name": "Contact AWFTEX",
    "about": {"@type": "Organization", "name": BRAND['legal_name'], "telephone": BRAND['phone_tel'], "email": BRAND['email']}
})
body = header(prefix) + crumbs + """
<section class="page-hero">%(media)s
  <div class="page-hero-inner">
    <h1>Contact AWFTEX</h1>
    <p>Send us your requirement and an engineer will follow up with the right product line and a formal quotation.</p>
  </div>
</section>

<section class="content-block wrap">
  <div class="two-col" style="align-items:start;">
    <div class="enquiry-panel">
      <h2>Send an Enquiry</h2>
      <p>Fields marked required help us route your enquiry to the right solution division faster.</p>
      <form class="enquiry-form">
        <div class="form-row"><input type="text" placeholder="Full name" required><input type="tel" placeholder="Phone number" required></div>
        <div class="form-row"><input type="email" placeholder="Email address" required><input type="text" placeholder="Company / Site name"></div>
        <div class="form-row full"><select><option value="">Solution of interest (optional)</option>%(division_options)s</select></div>
        <div class="form-row full"><textarea placeholder="Tell us about your requirement"></textarea></div>
        <button type="submit" class="cta">Submit Enquiry</button>
      </form>
      <p class="form-note">Prefer WhatsApp or a direct call? Use the contact details alongside this form — a real person picks these up.</p>
    </div>
    <div>
      <div class="loc-card" style="margin-bottom:20px;">
        <h3>%(pinicon)s Office Address</h3>
        <p>%(legal)s<br>%(office)s</p>
      </div>
      <div class="loc-card" style="margin-bottom:20px;">
        <h3>%(pinicon)s Manufacturing Unit</h3>
        <p>%(plant)s</p>
      </div>
      <div class="loc-card">
        <h3>%(spark)s Direct Contact</h3>
        <div class="contact-methods">%(methods)s</div>
      </div>
    </div>
  </div>
</section>
""" % dict(media=illustration(contact_seed, division_id='solar', tone="tone-hero", w=1600, h=700, alt="Contact AWFTEX", cls="page-hero-media", label="CONTACT"),
           division_options=division_options, pinicon=icon('pin'), spark=icon('spark'),
           legal=BRAND['legal_name'], office=BRAND['office_address'], plant=BRAND['plant_address'], methods=contact_methods_html)
body += footer(prefix)
html = page(prefix, "Contact | AWFTEX", "Contact AWFTEX for a quotation across any of our nine engineering solution divisions — office in New Delhi, manufacturing unit in Uttar Pradesh.",
            body, extra_head='<script type="application/ld+json">%s</script>' % contact_jsonld,
            canonical_path="company/contact.html", og_image=None)
with open(os.path.join(ROOT, 'company', 'contact.html'), 'w') as f:
    f.write(html)

# ---------------- SITEMAP & ROBOTS ----------------
sitemap_entries = "".join(
    '<url><loc>%s/%s</loc></url>' % (SITE_URL, u) for u in sorted(set(SITEMAP_URLS))
)
sitemap_xml = '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">%s</urlset>' % sitemap_entries
with open(os.path.join(ROOT, 'sitemap.xml'), 'w') as f:
    f.write(sitemap_xml)

robots_txt = "User-agent: *\nAllow: /\nSitemap: %s/sitemap.xml\n" % SITE_URL
with open(os.path.join(ROOT, 'robots.txt'), 'w') as f:
    f.write(robots_txt)

print("Product pages generated:", product_count)
print("Divisions:", len(DIVISIONS))
print("Sitemap URLs:", len(set(SITEMAP_URLS)))
